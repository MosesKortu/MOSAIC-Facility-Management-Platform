# Product Requirement Document (PRD): MOSAIC

**Platform Name:** MOSAIC (Management & Operational System for Advanced ICFO Cores)  
**Target Facilities:** Nano Fabrication Lab (NFL), Nanocharacterization Lab (NCL), Super-resolution Light Microscopy & Nanoscopy Facility (SLN)  
**Version:** 1.0-PROD  

---

## 1. Executive Summary & Objectives
MOSAIC is the next-generation core facility management platform for ICFO, replacing legacy software like Stratocore PPMS[cite: 3]. It unifies equipment booking, hardware access interlocks, staff support billing, user training prerequisites, and financial reporting across ICFO research centers.

### Key Performance Indicators (KPIs)
- **User Migration:** 100% researcher adoption from legacy systems within 30 days of launch.
- **Billing Efficiency:** 60% reduction in end-of-month financial reconciliation time via automated tariff stacking[cite: 1] and ERP exports.
- **Hardware SLA:** 99.9% uptime for WebSocket/MQTT physical power relays with <150ms actuation latency.

---

## 2. 3-Tier Role-Based Access Control (RBAC)

| User Role | Core Capabilities & UI Permissions |
| :--- | :--- |
| **Standard User** *(PhD, Postdoc, External)* | Authenticates via Shibboleth SSO; views tool schedules; completes embedded training quizzes; books equipment; unlocks hardware interlocks during active slots; views personal grant burn rates. |
| **Super User** *(ICFO Tech Lead / Supervisor)* | All Standard features plus: proxy booking for trainees; practical training sign-offs; manual interlock overrides for maintenance; service ticket feasibility reviews. |
| **Super Admin** *(Facility Manager)* | All Super User features plus: full Equipment Portfolio CRUD; base rate and staff tariff modifications[cite: 1]; user account elevation; global calendar locks; billing exports to ICFO ERP. |

---

## 3. Core Functional Requirements

### 3.1 Context-Aware Portal Entry & Deep Linking
- **URL Parameter Routing:** Direct links from ICFO facility pages (e.g., `icfo.eu/research/facilities/nfl/`) auto-load target system views (e.g., `mosaic.icfo.eu/start?facility=NFL&system=EBL_CRESTEC`).
- **Institutional Single Sign-On:** Seamless primary authentication using Shibboleth/OIDC (ICFO credentials), replacing legacy public account lists[cite: 3].
- **Guest Access Tab:** Magic-link email login for external academic and industrial collaborators.

### 3.2 Equipment Scheduling & Hardware Interlocks
- **Overlap Prevention:** Database-enforced scheduling rules using PostgreSQL `EXCLUDE USING gist` constraints to mathematically prevent double bookings.
- **Automated Technical Buffers:** Automatic pre/post-session padding (e.g., 30-minute chamber purge or vacuum pump-down) appended to reservations.
- **Hardware Relays:** Real-time event triggers using WebSockets and MQTT to toggle physical power relays on badge scan or in-app "Unlock" commands.

### 3.3 Dynamic Stacking Tariff Engine
- **Formula:** `Total Session Cost = (Base Instrument Rate * Hours) + (Support Tier Rate * Hours)`
- **Base Instrument Rates:** Configured per machine (e.g., EBL CRESTEC at €80.20/h, FIB Zeiss Orion at €133.70/h, Heidelberg MLA 150 at €65.30/h)[cite: 1].
- **Support Surcharges:** Autonomous (€0.00/h), Support Technician (+€40.00/h), or Supervisor (+€60.00/h)[cite: 1].

### 3.4 Embedded Training Engine (Native LMS)
- **Gatekeeping:** Unqualified users clicking "Book" trigger an interactive onboarding flow.
- **Theory Module:** Integrated PDF/SOP viewer and auto-graded multiple-choice quiz (80%+ passing threshold).
- **Practical Queue:** Automatic ticket dispatch to assigned Super Users for hands-on evaluation upon quiz completion.

### 3.5 Floating Reporting Toolbar
- **UI Element:** Persistent floating action bar on analytical views featuring three triggers:
  1. 📥 **Extract Data:** Export raw logs and executive summaries in CSV, XLSX, or JSON formats.
  2. 🖨️ **Print PDF:** Trigger `@media print` layout engine generating a styled A4 executive report.
  3. ✉️ **Email KPI Summary:** Open a pre-filled slide-over drawer to dispatch HTML reports to PIs or schedule automated monthly runs.

### 3.6 Multilingual Localization (EN / ES / CA)
- Instant client-side switching between English (`en`), Spanish (`es`), and Catalan (`ca`).
- Database dynamic fields stored in PostgreSQL `JSONB` structures (`{"en": "...", "es": "...", "ca": "..."}`).

---

## 4. Non-Functional Requirements & Fail-Safe Modes
- **Hardware Isolation:** Interlock relays maintain current state during network disconnects. Super Users have local PIN fallback options during SSO outages.
- **Audit Trails:** Immutable logging of all admin overrides, tariff changes[cite: 1], and role escalations for EU grant compliance.