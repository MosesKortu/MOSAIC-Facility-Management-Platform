# API Specification: MOSAIC Backend (Fastify)

**Protocol:** REST API & WebSockets  
**Base URL:** `https://mosaic.icfo.eu/api/v1`  
**Authentication:** Bearer JWT (Session token derived from Shibboleth SSO)

---

## 1. Authentication Endpoints

### `GET /auth/shibboleth`
Trigger institutional SSO redirection flow.

### `GET /auth/me`
Retrieve current user session metadata, role, active grants, and tool certifications.

**Response `200 OK`:**
```json
{
  "user_id": "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d",
  "full_name": "Dr. Alex Rivera",
  "role": "standard_user",
  "certifications": ["HEIDELBERG_MLA150", "RIE_OXFORD_100"],
  "grants": [
    { "grant_id": "a1b2...", "grant_code": "ES-MICINN-2026-042", "remaining_balance": 12450.00 }
  ]
}

2. Booking & Scheduling Endpoints
POST /bookings
Create a new equipment reservation.

Request Payload:

JSON
{
  "equipment_id": "c3d4e5...",
  "grant_id": "a1b2...",
  "start_time": "2026-10-15T09:00:00Z",
  "end_time": "2026-10-15T12:00:00Z",
  "support_requested": "technician"
}
Response 201 Created:

JSON
{
  "booking_id": "f8e7d6...",
  "calculated_base_cost": 313.50,
  "calculated_support_cost": 120.00,
  "total_cost": 433.50,
  "status": "confirmed"
}
3. Training & Prerequisites Endpoints
GET /training/:equipment_id
Fetch SOP document link and quiz payload for an instrument.

POST /training/submit-quiz
Submit quiz answers for auto-grading.

Request Payload:

JSON
{
  "module_id": "mod_123...",
  "answers": [ { "question_id": 1, "selected_option": 2 } ]
}
4. Analytics & Reporting Endpoints
GET /reports/extract
Query analytical metrics for export.

Query Parameters: facility=NFL&start_date=2026-01-01&format=csv

Response: 200 OK with binary CSV/JSON attachment[cite: 4].

POST /reports/email
Trigger dispatch of PDF/HTML KPI reports to PIs[cite: 4].

5. WebSockets & Hardware Interlock Relay Gateway
WS /ws/interlock/:equipment_id
Real-time bi-directional channel managing physical power relays.

Client Command (Unlock Signal):

JSON
{
  "action": "UNLOCK",
  "user_id": "9b1deb4d...",
  "booking_id": "f8e7d6..."
}
Server Broadcast (Relay State):

JSON
{
  "equipment_id": "c3d4e5...",
  "state": "ENERGIZED",
  "relay_status": "ONLINE",
  "timestamp": "2026-10-15T09:01:02Z"
}