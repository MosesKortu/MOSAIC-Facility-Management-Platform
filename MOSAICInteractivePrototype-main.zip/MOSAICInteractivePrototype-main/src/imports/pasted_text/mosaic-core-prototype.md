MOSAIC Core — Interactive Prototype
1. Prototype objective

The prototype should test whether a researcher can independently complete this task:

Find an instrument → understand requirements → check eligibility → choose a time → select a grant → understand the price → book → understand what happens when they arrive.

The prototype should also expose the major operational concepts without overwhelming the user.

Primary test task

Give a participant this scenario:

"You need to use the Heidelberg MLA 150 tomorrow for two hours. You want to work independently and charge the session to your research grant. Find out whether you can book it and complete the booking."

This single scenario tests:

Navigation
Equipment discovery
Availability
Training/certification
Pricing
Support selection
Grant selection
Booking
Confirmation
2. Prototype navigation

I recommend this primary navigation:

┌─────────────────────────────────────────┐
│ MOSAIC                         🔔  AB    │
├──────────────┬──────────────────────────┤
│              │                          │
│ Home         │                          │
│ Equipment    │     PAGE CONTENT         │
│ Calendar     │                          │
│ Training     │                          │
│ My Bookings  │                          │
│ Grants       │                          │
│              │                          │
│ ───────────  │                          │
│ Support      │                          │
│              │                          │
│              │                          │
│ Admin        │                          │
└──────────────┴──────────────────────────┘

For the first prototype, Admin can be visually present but not part of the main researcher test flow.

On mobile, the navigation should collapse into a bottom navigation / menu pattern.

3. Screen inventory

I would build approximately 15 screens.

Core researcher experience
Home
Equipment Explorer
Equipment Detail
Training & Certification
Training Detail / SOP
Quiz
Certification Status
Calendar / Availability
Booking Configuration
Grant Selection
Booking Review
Booking Confirmation
My Bookings
Active Session
Grants & Spending
Secondary screens
Notifications
Support
Profile
Staff prototype
Super User Dashboard
Certification Requests
Equipment Operations
Maintenance

22 screens is enough to make MOSAIC feel like a real product without designing the entire enterprise system.

4. Screen 01 — Home

This is the most important screen after the login.

Header

MOSAIC

Core Facilities

Right side:

Notifications
Language
User avatar
Hero
Good morning, Anna.

What are you working on today?

[ Search equipment, facility or capability... ]

Below the search:

Quick actions

[ Find equipment ]
[ My bookings ]
[ Training ]
[ Grants ]
Today's activity
TODAY

09:00 — Heidelberg MLA 150
NFL · 2 hours
Confirmed

14:00 — Oxford RIE
NFL · 1 hour
Confirmed
Equipment status
EQUIPMENT STATUS

NFL        12 available · 2 maintenance
NCL        8 available · 1 maintenance
SLN        7 available · 0 maintenance
Training status
YOUR ACCESS

Heidelberg MLA 150       ✓ Certified
Oxford RIE               ✓ Certified
EBL CRESTEC              ! Assessment required
Grant snapshot
RESEARCH GRANTS

EU-NANO-2026

€3,240 remaining
€1,760 used
Key design principle

The home page should answer:

"What do I need to know right now?"

rather than becoming an analytics dashboard.

5. Screen 02 — Equipment Explorer

This is the primary discovery screen.

Header
Equipment

[ Search equipment... ]

Filters
[ Facility ] [ Availability ] [ Certified ] [ Cost ]
Facility tabs
All     NFL     NCL     SLN
Equipment cards

Example:

Heidelberg MLA 150

Nano Fabrication Lab

Photolithography / maskless lithography

Available today
From €95 / hour

✓ You are certified

Next available:
Tomorrow · 09:00

CTA:

View equipment

Oxford RIE

Nano Fabrication Lab

Reactive ion etching

Available today
From €140 / hour

✓ You are certified

Next available:
Today · 16:00
EBL CRESTEC
From €180 / hour

⚠ Certification required

Complete practical assessment

This is important because equipment cards should expose eligibility, not just availability.

6. Screen 03 — Equipment Detail

Example:

Heidelberg MLA 150

Nano Fabrication Lab

Maskless lithography system for high-resolution patterning.

Status
● Available

Next available
Tomorrow · 09:00
Equipment information

Tabs:

Overview
Requirements
Availability
Pricing
Overview
Capabilities
Specifications
Sample requirements
Related SOPs
Your access
YOUR ACCESS

✓ Account verified
✓ SOP completed
✓ Quiz passed — 94%
✓ Practical assessment approved

You are certified to use this equipment.

This is one of the most important UX patterns in the application.

Pricing
BASE RATE

€95 / hour

Support options

○ Autonomous       +€0/h
○ Technician       +€40/h
○ Supervisor       +€60/h

CTA:

Check availability

7. Screen 04 — Training & Certification

This becomes a major navigation destination.

My Training
CERTIFICATION STATUS

8 certified
2 in progress
1 action required

Then equipment list:

Heidelberg MLA 150
██████████  Certified

Oxford RIE
██████████  Certified

EBL CRESTEC
██████░░░░  Practical assessment required
Action-required card
EBL CRESTEC

You passed the required quiz.

Next step:
Complete your practical assessment.

[ Request assessment ]

This avoids the classic problem of an opaque:

"Access denied."

8. Screen 05 — SOP / Training

Example:

Heidelberg MLA 150
Training
01  Read SOP              ✓
02  Safety Quiz           ✓
03  Practical Assessment  ✓
04  Certification         ✓

The SOP viewer should have:

Search
Table of contents
Version
Estimated reading time
Acknowledge button

Example:

SOP v3.2
Updated 14 Sep 2026

Estimated reading time: 12 min

[ Read SOP ]

────────────────────

Required before quiz
9. Screen 06 — Quiz

The prototype should include an actual interactive quiz.

Example:

What should you verify before starting the instrument?

Options:

○ Sample compatibility
○ Equipment status
○ Required PPE
○ All of the above

Progress:

Question 4 of 10
████████░░

After submission:

QUIZ PASSED

94%

Required: 80%

✓ Training requirement completed

[ Continue ]

This allows usability testing of the training experience rather than merely showing a static screen.

10. Screen 07 — Availability Calendar
Heidelberg MLA 150
September 2026

Mon Tue Wed Thu Fri
21  22  23  24  25

Time grid:

08:00  ───────────────
09:00  █ AVAILABLE ███
10:00  █ AVAILABLE ███
11:00  █ BOOKED █████
12:00  █ BOOKED █████
13:00  ───────────────
14:00  █ AVAILABLE ███
15:00  █ AVAILABLE ███
16:00  █ AVAILABLE ███

The user clicks:

Tomorrow · 09:00–11:00

Selected state:

2 hours selected

CTA:

Continue

11. Screen 08 — Booking Configuration

This screen brings together the business logic.

Book Heidelberg MLA 150
Date

22 September 2026

Time

09:00 – 11:00

Duration

2 hours

Support
How much support do you need?

● Autonomous
  €0/h

○ Technician
  +€40/h

○ Supervisor
  +€60/h
Estimated cost
Machine
€190

Support
€0

────────────────

Estimated total
€190

CTA:

Choose grant

12. Screen 09 — Grant Selection
Choose funding
Select a grant for this session.
Grant card
EU-NANO-2026

Available
€3,240

This booking
− €190

Remaining
€3,050

● Select

Another:

ICFO-INTERNAL

Available
€90

This booking
− €190

Insufficient funds

✕ Cannot use

This is a critical interaction to test.

The user shouldn't need to understand the underlying financial system.

13. Screen 10 — Booking Review

This is the final confirmation page.

Review your booking
Equipment

Heidelberg MLA 150

Nano Fabrication Lab

When

22 September 2026

09:00–11:00

Support

Autonomous

Funding

EU-NANO-2026

Cost
Equipment             €190
Support                  €0
──────────────────────────
Total                  €190
After this booking
Grant remaining
€3,050

Primary CTA:

Confirm booking

Secondary:

Back

14. Screen 11 — Booking Confirmation

This should feel extremely clear.

Booking confirmed

MOSAIC-28417

Heidelberg MLA 150

Tuesday
22 September 2026

09:00–11:00

Nano Fabrication Lab

Status:

Confirmed

Then:

✓ Certification verified
✓ Grant validated
✓ Equipment reserved

CTA:

View booking

Secondary:

Add to calendar

15. Screen 12 — My Bookings

This becomes the user's operational history.

Tabs:

Upcoming   Active   Completed

Card:

22 SEP
09:00–11:00

Heidelberg MLA 150
NFL

€190
EU-NANO-2026

CONFIRMED

Actions:

View

Cancel

16. Screen 13 — Active Session

This is where MOSAIC becomes different from a conventional booking platform.

Heidelberg MLA 150
Session active
09:42

Session ends at 11:00
Equipment state
● EQUIPMENT READY

Interlock
CONNECTED

Power
ON
Session
Started
09:00

Elapsed
42 min

Remaining
1h 18m
Cost
Current estimated cost

€66.50

The number can update as the session progresses.

Primary action:

End session

17. Screen 14 — Grants & Spending
Grants
EU-NANO-2026

€3,240
remaining

████████░░░░

€1,760 used
Recent spending
22 Sep
Heidelberg MLA 150
€190

20 Sep
Oxford RIE
€180

18 Sep
Heidelberg MLA 150
€95

This provides transparency without forcing users into accounting terminology.

18. Screen 15 — Profile / Settings

Include:

Profile
Language
Notifications
Authentication
Research groups
Grant access

Language:

English
Español
Català
19. Super User Prototype

For the second usability-test scenario, create a separate role.

After switching to Super User:

Super User Dashboard
GOOD MORNING, MARC

12 active bookings today
3 certification requests
1 equipment alert
2 maintenance events
Priority queue
ACTION REQUIRED

3 Certification requests

EBL CRESTEC
Anna Kowalski
Quiz: 94%
Practical assessment pending

[ Review ]
Equipment
NFL

● 11 Available
● 2 Active
● 1 Maintenance
20. Certification Review
Practical Assessment

Anna Kowalski

EBL CRESTEC
SOP
✓ Completed

Quiz
94%

Practical assessment
Pending

Assessment checklist:

□ PPE compliance
□ Startup procedure
□ Sample loading
□ Emergency procedure
□ Shutdown procedure

Actions:

Approve certification

Request reassessment

21. Maintenance Screen
Equipment Operations
Heidelberg MLA 150
● Available

Oxford RIE
● Maintenance
Until 16:00

EBL CRESTEC
● Active

Selecting Oxford RIE:

Maintenance

21 Sep
14:00–16:00

Reason
Scheduled chamber maintenance

Affected bookings
2

CTA:

Notify affected users

22. Prototype Navigation Map

This is the actual Figma prototype structure I would use:

                         ┌──────────────┐
                         │     HOME     │
                         └──────┬───────┘
                                │
             ┌──────────────────┼─────────────────┐
             │                  │                 │
             ▼                  ▼                 ▼
       EQUIPMENT            TRAINING          BOOKINGS
             │                  │                 │
             ▼                  ▼                 ▼
      EQUIPMENT DETAIL       SOP/QUIZ       BOOKING DETAIL
             │                  │                 │
             │                  ▼                 │
             │             CERTIFICATION         │
             │                                    │
             ▼                                    │
        AVAILABILITY                              │
             │                                    │
             ▼                                    │
       BOOKING CONFIG                             │
             │                                    │
             ▼                                    │
        GRANT SELECT                              │
             │                                    │
             ▼                                    │
        REVIEW BOOKING ◄──────────────────────────┘
             │
             ▼
       CONFIRMATION
             │
             ▼
       ACTIVE SESSION
23. Figma Prototype Interactions

These should be actual clickable transitions, not just static frames.

From	Action	To
Home	Equipment	Equipment Explorer
Home	Training	Training
Home	Booking	My Bookings
Equipment	Select machine	Equipment Detail
Equipment Detail	Availability	Calendar
Equipment Detail	Requirements	Training
Training	Open equipment	Training Detail
Training	Start quiz	Quiz
Quiz	Submit	Quiz Result
Quiz	Continue	Certification
Calendar	Select slot	Booking Configuration
Booking	Continue	Grant Selection
Grant	Select grant	Review
Review	Confirm	Confirmation
Confirmation	View booking	Booking Detail
Booking Detail	Start session	Active Session
Active Session	End	Session Complete
Navigation	Grants	Grants Dashboard
Navigation	Profile	Profile
24. Figma Components

To make the prototype scalable, I'd create a small MOSAIC design system first.

Core components
Button
Icon Button
Navigation item
Search field
Equipment card
Status badge
Certification badge
Grant card
Booking card
Calendar slot
Cost summary
Progress indicator
Alert
Modal
Toast
Tabs
Avatar
Table
Timeline
25. Design Language

The prototype should follow the PIXEurope identity from the PRD.

Canvas

#FFFFFF

Primary

PIX Blue — #032F9B

Accent

PIX Yellow — #FFCD01

Surface

Warm Grey — #F8F6F1

Text

Dark Charcoal — #333333

Use the blue primarily for:

Primary actions
Navigation selection
Links
Focus states

Use yellow sparingly for:

Important status
Attention
Selected highlights

The interface should remain predominantly white and calm.

26. Important Prototype Principle

I would not start by designing 22 beautiful screens.

Start with one complete clickable flow:

HOME
 ↓
EQUIPMENT
 ↓
EQUIPMENT DETAIL
 ↓
AVAILABILITY
 ↓
BOOKING
 ↓
GRANT
 ↓
REVIEW
 ↓
CONFIRMATION

Then give 5–10 researchers this task:

"You need to use the Heidelberg MLA 150 tomorrow for two hours. Please book it using your research grant."

Do not explain where anything is.

Observe:

Where they click first
Whether they understand "Equipment"
Whether they understand certification
Whether they understand support pricing
Whether they understand grant selection
Whether they notice the final cost
Whether they understand that the booking is actually confirmed

Those observations will tell us much more than asking users whether they "like" the interface.

27. Recommended Prototype Versions

I would create three Figma prototype modes:

Prototype A — Researcher

Primary usability test

Home → Equipment → Booking → Session

Prototype B — Super User

Dashboard → Certification → Assessment → Equipment → Maintenance

Prototype C — Super Admin

Dashboard → Equipment → Tariffs → Grants → Billing → Analytics