# Design System & UI Blueprint: MOSAIC (PIXEurope Identity)

**UI Framework:** Next.js App Router, Tailwind CSS, Shadcn UI / Radix Primitives  
**Iconography:** Lucide React  
**Brand Identity:** PIXEurope Light Theme (White primary background, PIX Blue, PIX Yellow, Warm Grey, Black)

---

## 1. Brand Color Palette & Light Mode Tokens

PIXEurope uses a clean, light-first aesthetic with a pure white canvas, high-contrast dark text, deep blue structural accents, vibrant photonic yellow highlights, and subtle warm grey surface cards.

| Role | Color Name | Hex Code | RGB / Palette Usage[cite: 3] |
| :--- | :--- | :--- | :--- |
| **Canvas / Background** | Pure White | `#FFFFFF` | Primary background canvas |
| **Surface / Card** | PIX Warm Grey | `#F8F6F1` | Background cards, light drawers, subtle borders (R248 G246 B241)[cite: 3] |
| **Primary Accent** | PIX Blue | `#032F9B` | Buttons, active navigation, key icons, primary branding (R3 G47 B155)[cite: 3] |
| **Secondary Accent** | PIX Yellow | `#FFCD01` | Feature badges, active highlights, warning states (R255 G205 B1)[cite: 3] |
| **Primary Text** | PIX Black | `#333333` | Body text, titles, dark UI borders (R51 G51 B51)[cite: 3] |
| **Muted Text** | PIX Neutral Gray | `#666666` | Secondary labels, disabled states, timestamps |
| **Status: Operational** | Emerald | `#10B981` | Active tools, operational interlocks |
| **Status: Maintenance** | PIX Yellow / Amber | `#FFCD01` | Scheduled downtime, maintenance warnings[cite: 3] |
| **Status: Offline** | Crimson Red | `#EF4444` | Emergency stop, system offline |

### Tailwind Configuration (`tailwind.config.js`)

```javascript
module.exports = {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        background: '#FFFFFF',
        foreground: '#333333',
        pix: {
          blue: {
            DEFAULT: '#032F9B', //[cite: 3]
            75: '#4263B4',
            50: '#8197CD',
            25: '#C0CBE6',
            10: '#E6EBF5',
          },
          yellow: {
            DEFAULT: '#FFCD01', //[cite: 3]
            75: '#FFDA41',
            50: '#FFE680',
            25: '#FFF3BF',
            10: '#FFF9E6',
          },
          black: '#333333',     //[cite: 3]
          warmgrey: '#F8F6F1',  //[cite: 3]
        },
        status: {
          operational: '#10B981',
          maintenance: '#FFCD01', //[cite: 3]
          offline: '#EF4444',
        }
      },
      fontFamily: {
        title: ['Eurostile', 'sans-serif'],           // Titles & Section Headings[cite: 3]
        body: ['Aptos', 'Inter', 'sans-serif'],        // Body Copy & Data Grids[cite: 3]
        display: ['Arkibal Display', 'sans-serif'],   // Brand Elements / Hero Headers[cite: 3]
      }
    }
  }
}

2. Floating Action Toolbar Component Blueprint (Light Theme)
Refactored for a high-contrast white background with PIX Blue accents, subtle shadows, and PIX Warm Grey container borders[cite: 3].

TypeScript
// src/components/reporting/FloatingToolbar.tsx
import React from 'react';
import { Download, Printer, Mail } from 'lucide-react';

interface FloatingToolbarProps {
  onExtract: () => void;
  onPrint: () => void;
  onEmail: () => void;
}

export const FloatingToolbar = ({ onExtract, onPrint, onEmail }: FloatingToolbarProps) => {
  return (
    <div className="fixed bottom-6 right-6 flex items-center gap-2 bg-white/95 backdrop-blur-md border border-slate-200 p-2 rounded-full shadow-xl shadow-slate-200/50 z-50">
      <button 
        onClick={onExtract}
        className="p-3 text-pix-black hover:text-pix-blue hover:bg-pix-warmgrey rounded-full transition-all duration-200"
        title="Extract CSV/JSON Data"
      >
        <Download className="w-5 h-5 stroke-[2]"/>
      </button>
      <div className="w-[1px] h-6 bg-slate-200" />
      <button 
        onClick={onPrint}
        className="p-3 text-pix-black hover:text-pix-blue hover:bg-pix-warmgrey rounded-full transition-all duration-200"
        title="Print A4 PDF Report"
      >
        <Printer className="w-5 h-5 stroke-[2]"/>
      </button>
      <div className="w-[1px] h-6 bg-slate-200" />
      <button 
        onClick={onEmail}
        className="p-3 text-pix-black hover:text-pix-blue hover:bg-pix-warmgrey rounded-full transition-all duration-200"
        title="Email KPI Summary"
      >
        <Mail className="w-5 h-5 stroke-[2]"/>
      </button>
    </div>
  );
};
3. Multilingual Localization Dictionaries (/locales)
Updated to integrate the PIXEurope branding and cleanroom infrastructure context[cite: 3].

English (/locales/en.json)
JSON
{
  "landing": {
    "title": "PIXEurope Photonic Core Facilities",
    "subtitle": "Advanced Photonic Integrated Circuits Infrastructure",
    "sso_button": "Login with Institutional Identity",
    "guest_tab": "External Partner Login"
  },
  "tariffs": {
    "base_rate": "Base Instrument Rate",
    "tech_support": "Technician Support (+€40/h)",
    "supervisor_support": "Supervisor Support (+€60/h)"
  },
  "status": {
    "operational": "Operational",
    "maintenance": "Maintenance Scheduled",
    "offline": "Offline"
  }
}
Spanish (/locales/es.json)
JSON
{
  "landing": {
    "title": "Infraestructura Fotónica PIXEurope
    ",
    "subtitle": "Circuitos Integrados Fotónicos Avanzados",
    "sso_button": "Iniciar sesión con Identidad Institucional",
    "guest_tab": "Acceso Colaborador Externo"
  },
  "tariffs": {
    "base_rate": "Tarifa Base de Equipo",
    "tech_support": "Soporte Técnico (+40 €/h)",
    "supervisor_support": "Soporte de Supervisor (+60 €/h)"
  },
  "status": {
    "operational": "Operativo",
    "maintenance": "Mantenimiento Programado",
    "offline": "Fuera de Servicio"
  }
}
Catalan (/locales/ca.json)
JSON
{
  "landing": {
    "title": "Infraestructura Fotònica PIXEurope",
    "subtitle": "Circuits Integrats Fotònics Avançats",
    "sso_button": "Inicia sessió amb Identitat Institucional",
    "guest_tab": "Accés Col·laborador Extern"
  },
  "tariffs": {
    "base_rate": "Tarifa Base d'Equip",
    "tech_support": "Suport Tècnic (+40 €/h)",
    "supervisor_support": "Suport de Supervisor (+60 €/h)"
  },
  "status": {
    "operational": "Operatiu",
    "maintenance": "Manteniment Programat",
    "offline": "Fora de Servei"
  }
}