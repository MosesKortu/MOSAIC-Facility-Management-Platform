import { useState } from 'react';
import Login from './pages/Login';
import Shell, { type Page, type Role } from './components/Shell';
import Home from './pages/Home';
import Equipment from './pages/Equipment';
import EquipmentDetail from './pages/EquipmentDetail';
import CalendarPage from './pages/CalendarPage';
import BookingConfig from './pages/BookingConfig';
import GrantSelect from './pages/GrantSelect';
import BookingReview from './pages/BookingReview';
import BookingConfirmation from './pages/BookingConfirmation';
import MyBookings from './pages/MyBookings';
import ActiveSession from './pages/ActiveSession';
import Training from './pages/Training';
import Grants from './pages/Grants';
import Admin from './pages/Admin';
import Analytics from './pages/Analytics';
import type { Tool } from './pages/Equipment';

interface BookingFlow {
  tool: Tool | null;
  date: string;
  start: string;
  end: string;
  support: string;
  supportRate: number;
  totalCost: number;
  grant: string;
  grantRemaining: number;
}

const EMPTY_FLOW: BookingFlow = {
  tool: null,
  date: '',
  start: '',
  end: '',
  support: 'autonomous',
  supportRate: 0,
  totalCost: 0,
  grant: '',
  grantRemaining: 0,
};

const BREADCRUMBS: Partial<Record<Page, { label: string; page: Page }[]>> = {
  'equipment-detail': [{ label: 'Equipment', page: 'equipment' }],
  'calendar': [{ label: 'Equipment', page: 'equipment' }, { label: 'Availability', page: 'calendar' }],
  'booking-config': [{ label: 'Equipment', page: 'equipment' }, { label: 'Book', page: 'booking-config' }],
  'grant-select': [{ label: 'Equipment', page: 'equipment' }, { label: 'Book', page: 'booking-config' }, { label: 'Choose Grant', page: 'grant-select' }],
  'booking-review': [{ label: 'Equipment', page: 'equipment' }, { label: 'Book', page: 'booking-config' }, { label: 'Review', page: 'booking-review' }],
  'booking-confirm': [],
  'active-session': [{ label: 'My Bookings', page: 'my-bookings' }, { label: 'Active Session', page: 'active-session' }],
};

export default function App() {
  const [role, setRole] = useState<Role | null>(null);
  const [page, setPage] = useState<Page>('home');
  const [flow, setFlow] = useState<BookingFlow>(EMPTY_FLOW);

  if (!role) {
    return (
      <Login
        onLogin={(r) => {
          setRole(r);
          setPage('home');
        }}
      />
    );
  }

  const navigate = (p: Page, extra?: Record<string, unknown>) => {
    if (p === 'admin' && role === 'standard') return;
    setPage(p);
  };

  const breadcrumb = BREADCRUMBS[page];

  const renderPage = () => {
    switch (page) {
      case 'home':
        return <Home onNavigate={navigate} />;

      case 'equipment':
        return (
          <Equipment
            onSelectTool={(tool) => {
              setFlow({ ...EMPTY_FLOW, tool });
              setPage('equipment-detail');
            }}
            onNavigate={navigate}
          />
        );

      case 'equipment-detail':
        return flow.tool ? (
          <EquipmentDetail
            tool={flow.tool}
            onCheckAvailability={() => setPage('calendar')}
            onGoToTraining={() => setPage('training')}
          />
        ) : null;

      case 'calendar':
        return flow.tool ? (
          <CalendarPage
            tool={flow.tool}
            onSelectSlot={(date, start, end) => {
              setFlow((f) => ({ ...f, date, start, end }));
              setPage('booking-config');
            }}
          />
        ) : null;

      case 'booking-config':
        return flow.tool ? (
          <BookingConfig
            tool={flow.tool}
            date={flow.date}
            start={flow.start}
            end={flow.end}
            onContinue={(support, supportRate, cost) => {
              setFlow((f) => ({ ...f, support, supportRate, totalCost: cost }));
              setPage('grant-select');
            }}
          />
        ) : null;

      case 'grant-select':
        return (
          <GrantSelect
            bookingCost={flow.totalCost}
            onSelect={(grant, grantRemaining) => {
              setFlow((f) => ({ ...f, grant, grantRemaining }));
              setPage('booking-review');
            }}
          />
        );

      case 'booking-review':
        return flow.tool ? (
          <BookingReview
            tool={flow.tool}
            date={flow.date}
            start={flow.start}
            end={flow.end}
            support={flow.support}
            supportRate={flow.supportRate}
            grant={flow.grant}
            grantRemaining={flow.grantRemaining}
            totalCost={flow.totalCost}
            onConfirm={() => setPage('booking-confirm')}
            onBack={() => setPage('booking-config')}
          />
        ) : null;

      case 'booking-confirm':
        return flow.tool ? (
          <BookingConfirmation
            tool={flow.tool}
            date={flow.date}
            start={flow.start}
            end={flow.end}
            grant={flow.grant}
            totalCost={flow.totalCost}
            onNavigate={(p) => {
              if (p === 'home') setFlow(EMPTY_FLOW);
              setPage(p);
            }}
          />
        ) : null;

      case 'training':
        return <Training />;

      case 'my-bookings':
        return (
          <MyBookings
            onNavigate={navigate}
            onStartSession={() => setPage('active-session')}
          />
        );

      case 'active-session':
        return <ActiveSession onNavigate={navigate} />;

      case 'grants':
        return <Grants onNavigate={navigate} />;

      case 'admin':
        return <Admin />;

      default:
        return <Home onNavigate={navigate} />;
    }
  };

  return (
    <Shell
      role={role}
      currentPage={page}
      onNavigate={navigate}
      onLogout={() => { setRole(null); setPage('home'); setFlow(EMPTY_FLOW); }}
      breadcrumb={breadcrumb}
    >
      {renderPage()}
    </Shell>
  );
}
