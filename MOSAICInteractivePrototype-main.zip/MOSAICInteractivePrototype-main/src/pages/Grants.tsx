import type { Page } from '../components/Shell';

interface GrantsProps {
  onNavigate: (page: Page) => void;
}

const GRANTS = [
  {
    code: 'EU-NANO-2026',
    name: 'EU Nano-Photonics Excellence Grant',
    total: 5000,
    used: 1760,
    remaining: 3240,
    pi: 'Prof. Lluis Torner',
    expires: '31 Dec 2026',
    spending: [
      { date: '22 Sep', tool: 'Heidelberg MLA 150', amount: 190 },
      { date: '20 Sep', tool: 'Oxford Instruments RIE', amount: 280 },
      { date: '18 Sep', tool: 'Heidelberg MLA 150', amount: 95 },
      { date: '15 Sep', tool: 'ALD Beneq TFS-200', amount: 174 },
      { date: '10 Sep', tool: 'EBL CRESTEC', amount: 360 },
      { date: '05 Sep', tool: 'Oxford Instruments RIE', amount: 140 },
      { date: '28 Aug', tool: 'Heidelberg MLA 150', amount: 190 },
      { date: '22 Aug', tool: 'JEOL SEM 7000F', amount: 144 },
    ],
  },
  {
    code: 'ES-MICINN-2026',
    name: 'Spanish MICINN Research Grant',
    total: 12000,
    used: 3880,
    remaining: 8120,
    pi: 'Prof. Maciej Lewenstein',
    expires: '30 Jun 2027',
    spending: [
      { date: '24 Sep', tool: 'JEOL SEM 7000F', amount: 216 },
      { date: '17 Sep', tool: 'ALD Beneq TFS-200', amount: 174 },
      { date: '12 Sep', tool: 'FIB Zeiss Orion', amount: 401 },
    ],
  },
];

export default function Grants({ onNavigate }: GrantsProps) {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-2 gap-4">
        {[
          { label: 'Total Available', value: `€${GRANTS.reduce((a, g) => a + g.remaining, 0).toLocaleString()}`, sub: 'across all grants' },
          { label: 'Total Used (YTD)', value: `€${GRANTS.reduce((a, g) => a + g.used, 0).toLocaleString()}`, sub: 'since January 2026' },
        ].map((s) => (
          <div
            key={s.label}
            className="p-5 rounded-xl"
            style={{ background: '#fff', border: '1px solid var(--border)' }}
          >
            <div style={{ fontSize: 12, color: 'var(--muted-foreground)', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 6 }}>
              {s.label}
            </div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 32, fontWeight: 700, color: 'var(--primary)' }}>
              {s.value}
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 2 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Grant cards */}
      {GRANTS.map((grant) => {
        const pct = Math.round((grant.used / grant.total) * 100);
        return (
          <div
            key={grant.code}
            className="rounded-xl overflow-hidden"
            style={{ background: '#fff', border: '1px solid var(--border)' }}
          >
            {/* Header */}
            <div className="p-5" style={{ borderBottom: '1px solid var(--border)' }}>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 20, fontWeight: 700, color: 'var(--primary)' }}>
                    {grant.code}
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--muted-foreground)', marginTop: 2 }}>{grant.name}</div>
                </div>
                <div className="text-right shrink-0">
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 26, fontWeight: 700, color: '#10B981', lineHeight: 1 }}>
                    €{grant.remaining.toLocaleString()}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginTop: 2 }}>remaining</div>
                </div>
              </div>

              {/* Progress */}
              <div className="mt-4">
                <div style={{ height: 8, background: 'var(--muted)', borderRadius: 4, overflow: 'hidden' }}>
                  <div
                    style={{
                      height: '100%',
                      width: `${pct}%`,
                      background: pct > 80 ? '#EF4444' : pct > 60 ? 'var(--accent)' : 'var(--primary)',
                      borderRadius: 4,
                    }}
                  />
                </div>
                <div className="flex justify-between mt-1.5">
                  <span style={{ fontSize: 11, color: 'var(--muted-foreground)' }}>€{grant.used.toLocaleString()} used ({pct}%)</span>
                  <span style={{ fontSize: 11, color: 'var(--muted-foreground)' }}>of €{grant.total.toLocaleString()}</span>
                </div>
              </div>

              {/* Meta */}
              <div className="flex gap-4 mt-3">
                <span style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>PI: <strong style={{ color: 'var(--foreground)' }}>{grant.pi}</strong></span>
                <span style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>Expires: <strong style={{ color: 'var(--foreground)' }}>{grant.expires}</strong></span>
              </div>
            </div>

            {/* Recent spending */}
            <div className="p-5">
              <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 12 }}>
                Recent Spending
              </div>
              <div className="space-y-2">
                {grant.spending.slice(0, 5).map((s, i) => (
                  <div key={i} className="flex items-center gap-3 py-1.5" style={{ borderBottom: i < 4 ? '1px solid var(--border)' : 'none' }}>
                    <span
                      className="px-2 py-0.5 rounded text-xs font-semibold shrink-0"
                      style={{ background: 'var(--card)', color: 'var(--muted-foreground)', fontFamily: 'JetBrains Mono, monospace', minWidth: 52, textAlign: 'center' }}
                    >
                      {s.date}
                    </span>
                    <span style={{ fontSize: 13, color: 'var(--foreground)', flex: 1 }}>{s.tool}</span>
                    <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14, fontWeight: 600, color: 'var(--primary)' }}>
                      €{s.amount}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      })}

      {/* Book more */}
      <button
        onClick={() => onNavigate('equipment')}
        className="w-full py-3 rounded-xl text-sm font-semibold transition-all hover:opacity-90"
        style={{ background: 'var(--primary)', color: '#fff' }}
      >
        Book a session →
      </button>
    </div>
  );
}
