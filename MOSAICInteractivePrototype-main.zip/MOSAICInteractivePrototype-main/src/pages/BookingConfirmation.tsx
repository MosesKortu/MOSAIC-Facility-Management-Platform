import type { Tool } from './Equipment';
import type { Page } from '../components/Shell';

interface BookingConfirmationProps {
  tool: Tool;
  date: string;
  start: string;
  end: string;
  grant: string;
  totalCost: number;
  onNavigate: (page: Page) => void;
}

export default function BookingConfirmation({ tool, date, start, end, grant, totalCost, onNavigate }: BookingConfirmationProps) {
  const bookingRef = `MOSAIC-${Math.floor(28000 + Math.random() * 999)}`;

  return (
    <div className="max-w-md mx-auto">
      {/* Success animation area */}
      <div className="text-center mb-8">
        <div
          className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-5"
          style={{ background: '#D1FAE5' }}
        >
          <svg className="w-10 h-10" style={{ color: '#10B981' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
        <h1 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 32, fontWeight: 700, color: 'var(--primary)', marginBottom: 4 }}>
          Booking confirmed
        </h1>
        <div
          className="inline-block px-4 py-1.5 rounded-full"
          style={{ background: 'var(--card)', border: '1px solid var(--border)', fontFamily: 'JetBrains Mono, monospace', fontSize: 13, fontWeight: 700, color: 'var(--primary)' }}
        >
          {bookingRef}
        </div>
      </div>

      {/* Booking card */}
      <div
        className="rounded-2xl overflow-hidden mb-5"
        style={{ border: '1px solid var(--border)', background: '#fff' }}
      >
        <div className="p-6" style={{ background: 'var(--primary)' }}>
          <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 24, fontWeight: 700, color: '#fff', marginBottom: 4 }}>
            {tool.name}
          </div>
          <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.65)' }}>{tool.facility} · {tool.category}</div>
        </div>

        <div className="p-6 space-y-4">
          {/* When */}
          <div className="text-center py-4" style={{ borderBottom: '1px solid var(--border)' }}>
            <div style={{ fontSize: 13, color: 'var(--muted-foreground)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.07em', fontWeight: 600 }}>
              When
            </div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 26, fontWeight: 700, color: 'var(--primary)' }}>
              {date}
            </div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 20, fontWeight: 600, color: 'var(--foreground)', marginTop: 4 }}>
              {start} – {end}
            </div>
          </div>

          {/* Status checks */}
          <div className="space-y-2">
            {[
              'Certification verified',
              'Grant validated',
              'Equipment reserved',
              `${grant} charged €${totalCost.toFixed(0)}`,
            ].map((item) => (
              <div key={item} className="flex items-center gap-3">
                <svg className="w-4 h-4 shrink-0" style={{ color: '#10B981' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                <span style={{ fontSize: 14, color: 'var(--foreground)' }}>{item}</span>
              </div>
            ))}
          </div>

          {/* Status badge */}
          <div
            className="flex items-center justify-center gap-2 py-3 rounded-xl"
            style={{ background: '#D1FAE5', border: '1px solid #A7F3D0' }}
          >
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: '#10B981' }} />
            <span style={{ fontSize: 14, fontWeight: 700, color: '#065F46' }}>Status: Confirmed</span>
          </div>
        </div>
      </div>

      {/* What happens next */}
      <div
        className="rounded-xl p-5 mb-5"
        style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
      >
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>
          When you arrive
        </div>
        <div className="space-y-2">
          {[
            'Scan your ICFO badge at the bay door',
            'MOSAIC will verify your active booking',
            'Equipment interlock will be automatically released',
            'Session timer starts — you will see cost accruing in My Bookings',
          ].map((step, i) => (
            <div key={i} className="flex items-start gap-3">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5"
                style={{ background: 'var(--primary)', color: '#fff' }}
              >
                {i + 1}
              </div>
              <span style={{ fontSize: 13, color: 'var(--foreground)', lineHeight: 1.5 }}>{step}</span>
            </div>
          ))}
        </div>
      </div>

      {/* CTAs */}
      <div className="space-y-3">
        <button
          onClick={() => onNavigate('my-bookings')}
          className="w-full py-3.5 rounded-xl font-semibold text-white transition-all hover:opacity-90"
          style={{ background: 'var(--primary)', fontSize: 15 }}
        >
          View booking
        </button>
        <button
          onClick={() => onNavigate('home')}
          className="w-full py-3 text-sm"
          style={{ color: 'var(--muted-foreground)' }}
        >
          Add to calendar (coming soon)
        </button>
      </div>
    </div>
  );
}
