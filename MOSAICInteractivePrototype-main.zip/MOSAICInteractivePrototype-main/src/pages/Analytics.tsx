import { useState } from 'react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

const MONTHLY_REVENUE = [
  { month: 'Jan', revenue: 42800, sessions: 284 },
  { month: 'Feb', revenue: 38200, sessions: 261 },
  { month: 'Mar', revenue: 51600, sessions: 348 },
  { month: 'Apr', revenue: 47900, sessions: 312 },
  { month: 'May', revenue: 55300, sessions: 371 },
  { month: 'Jun', revenue: 61200, sessions: 402 },
  { month: 'Jul', revenue: 43700, sessions: 289 },
  { month: 'Aug', revenue: 38900, sessions: 247 },
  { month: 'Sep', revenue: 58400, sessions: 389 },
];

const UTILIZATION = [
  { tool: 'EBL-CRESTEC', utilization: 87, revenue: 18240 },
  { tool: 'HDB-MLA150', utilization: 72, revenue: 12680 },
  { tool: 'RIE-OXFORD', utilization: 64, revenue: 9840 },
  { tool: 'FIB-ORION', utilization: 31, revenue: 5420 },
  { tool: 'ALD-BENEQ', utilization: 55, revenue: 7120 },
  { tool: 'SPUTTER', utilization: 18, revenue: 2100 },
];

const SUPPORT_SPLIT = [
  { name: 'Autonomous', value: 58, color: '#032F9B' },
  { name: 'Technician', value: 31, color: '#FFCD01' },
  { name: 'Supervisor', value: 11, color: '#10B981' },
];

const KPI_CARDS = [
  { label: 'YTD Revenue', value: '€437,900', delta: '+12.4%', up: true },
  { label: 'Total Sessions', value: '2,903', delta: '+8.1%', up: true },
  { label: 'Avg Utilization', value: '54.5%', delta: '-3.2%', up: false },
  { label: 'Active Users', value: '147', delta: '+22', up: true },
];

const FACILITIES = ['NFL', 'NCL', 'SLN', 'All Facilities'];

export default function Analytics() {
  const [facility, setFacility] = useState('NFL');
  const [range, setRange] = useState('2026');
  const [showEmail, setShowEmail] = useState(false);
  const [emailForm, setEmailForm] = useState({ to: 'pi-group@icfo.eu', subject: 'NFL KPI Report — September 2026', schedule: 'monthly' });

  const handleExtract = () => {
    alert('Extracting data as CSV… (demo)\nFields: Date, Tool, User, Grant, Duration, Base Cost, Support Cost, Total');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="flex gap-2">
          {FACILITIES.map((f) => (
            <button
              key={f}
              onClick={() => setFacility(f)}
              className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
              style={{
                background: facility === f ? 'var(--primary)' : 'var(--card)',
                color: facility === f ? '#fff' : 'var(--foreground)',
                border: `1px solid ${facility === f ? 'var(--primary)' : 'var(--border)'}`,
                fontFamily: 'Barlow Condensed, sans-serif',
                letterSpacing: '0.05em',
              }}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="ml-auto flex gap-2">
          {['2024', '2025', '2026'].map((y) => (
            <button
              key={y}
              onClick={() => setRange(y)}
              className="px-3 py-1.5 rounded-lg text-sm transition-all"
              style={{
                background: range === y ? 'var(--accent)' : 'var(--card)',
                color: range === y ? 'var(--accent-foreground)' : 'var(--muted-foreground)',
                border: `1px solid ${range === y ? 'var(--accent)' : 'var(--border)'}`,
                fontWeight: range === y ? 700 : 400,
              }}
            >
              {y}
            </button>
          ))}
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {KPI_CARDS.map((kpi) => (
          <div
            key={kpi.label}
            className="p-5 rounded-xl"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            <div style={{ fontSize: 12, color: 'var(--muted-foreground)', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 8 }}>
              {kpi.label}
            </div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 28, fontWeight: 700, color: 'var(--primary)', lineHeight: 1 }}>
              {kpi.value}
            </div>
            <div
              className="flex items-center gap-1 mt-2"
              style={{ color: kpi.up ? '#10B981' : '#EF4444', fontSize: 12, fontWeight: 600 }}
            >
              <span>{kpi.up ? '↑' : '↓'}</span>
              <span>{kpi.delta}</span>
              <span style={{ color: 'var(--muted-foreground)', fontWeight: 400 }}> vs prior year</span>
            </div>
          </div>
        ))}
      </div>

      {/* Revenue chart */}
      <div
        className="p-6 rounded-xl"
        style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 18, fontWeight: 700, color: 'var(--primary)' }}>
              Monthly Revenue & Sessions
            </div>
            <div style={{ fontSize: 13, color: 'var(--muted-foreground)' }}>
              {facility} · {range}
            </div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={240}>
          <AreaChart data={MONTHLY_REVENUE} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#032F9B" stopOpacity={0.18} />
                <stop offset="100%" stopColor="#032F9B" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} tickFormatter={(v) => `€${(v/1000).toFixed(0)}k`} />
            <Tooltip
              formatter={(v: number, name: string) => [name === 'revenue' ? `€${v.toLocaleString()}` : v, name === 'revenue' ? 'Revenue' : 'Sessions']}
              contentStyle={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13 }}
            />
            <Area type="monotone" dataKey="revenue" stroke="#032F9B" strokeWidth={2} fill="url(#revGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Utilization + Support split */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Utilization */}
        <div
          className="p-6 rounded-xl"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
        >
          <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 18, fontWeight: 700, color: 'var(--primary)', marginBottom: 16 }}>
            Instrument Utilization
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={UTILIZATION} layout="vertical" margin={{ top: 0, right: 20, left: 60, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
              <YAxis type="category" dataKey="tool" tick={{ fontSize: 11, fill: 'var(--muted-foreground)', fontFamily: 'JetBrains Mono, monospace' }} axisLine={false} tickLine={false} />
              <Tooltip
                formatter={(v: number) => [`${v}%`, 'Utilization']}
                contentStyle={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13 }}
              />
              <Bar dataKey="utilization" radius={[0, 4, 4, 0]}>
                {UTILIZATION.map((entry) => (
                  <Cell
                    key={entry.tool}
                    fill={entry.utilization >= 70 ? '#10B981' : entry.utilization >= 40 ? '#FFCD01' : '#EF4444'}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Support split */}
        <div
          className="p-6 rounded-xl flex flex-col"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
        >
          <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 18, fontWeight: 700, color: 'var(--primary)', marginBottom: 16 }}>
            Support Mode Distribution
          </div>
          <div className="flex-1 flex items-center gap-6">
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={SUPPORT_SPLIT} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" paddingAngle={3}>
                  {SUPPORT_SPLIT.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => [`${v}%`, '']} contentStyle={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 8, fontSize: 13 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-3 flex-1">
              {SUPPORT_SPLIT.map((s) => (
                <div key={s.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: s.color }} />
                    <span style={{ fontSize: 13, color: 'var(--foreground)' }}>{s.name}</span>
                  </div>
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14, fontWeight: 600, color: 'var(--foreground)' }}>
                    {s.value}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Revenue by tool table */}
      <div
        className="rounded-xl overflow-hidden"
        style={{ border: '1px solid var(--border)' }}
      >
        <div className="px-6 py-4" style={{ background: 'var(--card)', borderBottom: '1px solid var(--border)' }}>
          <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 18, fontWeight: 700, color: 'var(--primary)' }}>
            Revenue by Instrument
          </div>
        </div>
        <table className="w-full" style={{ background: '#fff' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              {['Instrument', 'Utilization', 'Sessions YTD', 'Revenue YTD', 'Trend'].map((h) => (
                <th key={h} className="px-5 py-3 text-left" style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {UTILIZATION.map((row, i) => (
              <tr
                key={row.tool}
                style={{ borderBottom: i < UTILIZATION.length - 1 ? '1px solid var(--border)' : 'none' }}
              >
                <td className="px-5 py-4" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, color: 'var(--primary)', fontWeight: 500 }}>
                  {row.tool}
                </td>
                <td className="px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div style={{ flex: 1, height: 6, background: 'var(--muted)', borderRadius: 3 }}>
                      <div
                        style={{
                          height: '100%',
                          width: `${row.utilization}%`,
                          background: row.utilization >= 70 ? '#10B981' : row.utilization >= 40 ? '#FFCD01' : '#EF4444',
                          borderRadius: 3,
                        }}
                      />
                    </div>
                    <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: 'var(--foreground)', width: 36 }}>
                      {row.utilization}%
                    </span>
                  </div>
                </td>
                <td className="px-5 py-4" style={{ fontSize: 14, color: 'var(--foreground)' }}>
                  {Math.round(row.utilization * 4.2)}
                </td>
                <td className="px-5 py-4" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14, fontWeight: 600, color: 'var(--primary)' }}>
                  €{row.revenue.toLocaleString()}
                </td>
                <td className="px-5 py-4">
                  <span style={{ fontSize: 12, color: row.utilization > 50 ? '#10B981' : '#EF4444', fontWeight: 600 }}>
                    {row.utilization > 50 ? '↑' : '↓'} {Math.abs(Math.round((row.utilization - 55) * 0.8))}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Floating Toolbar */}
      <div className="fixed bottom-6 right-6 flex items-center gap-2 z-50 rounded-full px-2 py-2 shadow-xl"
        style={{ background: 'rgba(255,255,255,0.97)', border: '1px solid var(--border)', backdropFilter: 'blur(8px)' }}
      >
        <button
          onClick={handleExtract}
          className="p-3 rounded-full transition-all"
          title="Extract CSV/JSON"
          style={{ color: 'var(--foreground)' }}
          onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--card)'; e.currentTarget.style.color = 'var(--primary)'; }}
          onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--foreground)'; }}
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
        </button>
        <div style={{ width: 1, height: 24, background: 'var(--border)' }} />
        <button
          onClick={handlePrint}
          className="p-3 rounded-full transition-all"
          title="Print PDF Report"
          style={{ color: 'var(--foreground)' }}
          onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--card)'; e.currentTarget.style.color = 'var(--primary)'; }}
          onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--foreground)'; }}
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="6 9 6 2 18 2 18 9"/>
            <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/>
            <rect x="6" y="14" width="12" height="8"/>
          </svg>
        </button>
        <div style={{ width: 1, height: 24, background: 'var(--border)' }} />
        <button
          onClick={() => setShowEmail(true)}
          className="p-3 rounded-full transition-all"
          title="Email KPI Summary"
          style={{ color: 'var(--foreground)' }}
          onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--card)'; e.currentTarget.style.color = 'var(--primary)'; }}
          onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--foreground)'; }}
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
        </button>
      </div>

      {/* Email slide-over */}
      {showEmail && (
        <div
          className="fixed inset-0 z-50 flex justify-end"
          style={{ background: 'rgba(0,0,0,0.3)' }}
          onClick={() => setShowEmail(false)}
        >
          <div
            className="w-full max-w-md h-full p-8 overflow-auto"
            style={{ background: '#fff', boxShadow: '-4px 0 24px rgba(0,0,0,0.12)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-8">
              <h2 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 22, fontWeight: 700, color: 'var(--primary)' }}>
                Email KPI Report
              </h2>
              <button onClick={() => setShowEmail(false)} style={{ color: 'var(--muted-foreground)' }}>
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
            </div>

            <div className="space-y-5">
              <div>
                <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 4 }}>
                  Recipients
                </label>
                <input
                  value={emailForm.to}
                  onChange={(e) => setEmailForm({ ...emailForm, to: e.target.value })}
                  placeholder="pi@institution.edu"
                  className="w-full px-4 py-2.5 rounded-lg text-sm outline-none"
                  style={{ border: '1px solid var(--border)', background: 'var(--card)' }}
                />
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 4 }}>
                  Subject
                </label>
                <input
                  value={emailForm.subject}
                  onChange={(e) => setEmailForm({ ...emailForm, subject: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg text-sm outline-none"
                  style={{ border: '1px solid var(--border)', background: 'var(--card)' }}
                />
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 4 }}>
                  Report Format
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['HTML', 'PDF', 'XLSX'].map((f) => (
                    <button
                      key={f}
                      className="py-2 rounded-lg text-sm font-semibold transition-all"
                      style={{
                        border: '1px solid var(--border)',
                        background: f === 'HTML' ? 'var(--primary)' : 'var(--card)',
                        color: f === 'HTML' ? '#fff' : 'var(--muted-foreground)',
                        fontFamily: 'Barlow Condensed, sans-serif',
                        letterSpacing: '0.05em',
                      }}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 4 }}>
                  Schedule
                </label>
                <select
                  value={emailForm.schedule}
                  onChange={(e) => setEmailForm({ ...emailForm, schedule: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg text-sm outline-none"
                  style={{ border: '1px solid var(--border)', background: 'var(--card)' }}
                >
                  <option value="now">Send Now</option>
                  <option value="monthly">Monthly (1st of month)</option>
                  <option value="quarterly">Quarterly</option>
                </select>
              </div>

              {/* Content preview */}
              <div className="p-4 rounded-lg" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 10 }}>
                  Will include
                </div>
                {['YTD Revenue Summary', 'Instrument Utilization Chart', 'Top Users by Consumption', 'Grant Burn Rate Overview', 'Maintenance Events Log'].map((item) => (
                  <div key={item} className="flex items-center gap-2 py-1">
                    <svg className="w-3.5 h-3.5" style={{ color: '#10B981' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                    <span style={{ fontSize: 13, color: 'var(--foreground)' }}>{item}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => { alert('Report dispatched!'); setShowEmail(false); }}
                className="w-full py-3 rounded-lg font-semibold text-white transition-all hover:opacity-90"
                style={{ background: 'var(--primary)', fontSize: 15 }}
              >
                Send Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
