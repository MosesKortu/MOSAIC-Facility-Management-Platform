import { useState } from 'react';

interface LoginProps {
  onLogin: (role: 'standard' | 'superuser' | 'admin') => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [tab, setTab] = useState<'sso' | 'guest'>('sso');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [facility, setFacility] = useState('NFL');

  const handleSSO = (role: 'standard' | 'superuser' | 'admin') => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin(role);
    }, 1000);
  };

  const handleGuestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin('standard');
    }, 1200);
  };

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--background)' }}>
      {/* Left panel — brand */}
      <div
        className="hidden lg:flex flex-col justify-between w-[480px] shrink-0 p-12"
        style={{ background: 'var(--primary)' }}
      >
        <div>
          {/* Logo */}
          <div className="flex items-center gap-3 mb-16">
            <div
              className="w-10 h-10 rounded flex items-center justify-center font-bold text-lg"
              style={{ background: 'var(--accent)', color: 'var(--primary)', fontFamily: 'Barlow Condensed, sans-serif' }}
            >
              M
            </div>
            <span style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 22, fontWeight: 700, color: '#fff', letterSpacing: '0.08em' }}>
              MOSAIC
            </span>
          </div>

          <h1 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 48, fontWeight: 700, color: '#fff', lineHeight: 1.1, marginBottom: 16 }}>
            PIXEurope<br />Photonic Core<br />Facilities
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: 15, lineHeight: 1.6 }}>
            Advanced Photonic Integrated Circuits Infrastructure — unified management for NFL, NCL, and SLN facilities.
          </p>
        </div>

        {/* Facility stats */}
        <div className="space-y-4">
          {[
            { label: 'Nano Fabrication Lab', code: 'NFL', tools: 14, status: 'Operational' },
            { label: 'Nanocharacterization Lab', code: 'NCL', tools: 9, status: 'Operational' },
            { label: 'Super-res Light Microscopy', code: 'SLN', tools: 6, status: '1 in Maintenance' },
          ].map((f) => (
            <div
              key={f.code}
              className="flex items-center justify-between p-4 rounded-lg"
              style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}
            >
              <div>
                <div style={{ color: '#fff', fontWeight: 600, fontSize: 14 }}>{f.code}</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12 }}>{f.label}</div>
              </div>
              <div className="text-right">
                <div style={{ color: 'rgba(255,255,255,0.9)', fontFamily: 'JetBrains Mono, monospace', fontSize: 13 }}>{f.tools} tools</div>
                <div style={{ fontSize: 11, color: f.status === 'Operational' ? 'var(--status-ok)' : 'var(--status-warn)' }}>{f.status}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: 12 }}>
          ICFO · Institut de Ciències Fotòniques · PIXEurope v1.0
        </div>
      </div>

      {/* Right panel — login form */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 lg:p-16">
        {/* Mobile logo */}
        <div className="lg:hidden flex items-center gap-3 mb-10">
          <div
            className="w-9 h-9 rounded flex items-center justify-center font-bold"
            style={{ background: 'var(--primary)', color: 'var(--accent)', fontFamily: 'Barlow Condensed, sans-serif' }}
          >
            M
          </div>
          <span style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 20, fontWeight: 700, color: 'var(--primary)', letterSpacing: '0.08em' }}>
            MOSAIC
          </span>
        </div>

        <div className="w-full max-w-md">
          <h2 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 32, fontWeight: 700, color: 'var(--primary)', marginBottom: 4 }}>
            Welcome back
          </h2>
          <p style={{ color: 'var(--muted-foreground)', fontSize: 15, marginBottom: 32 }}>
            Sign in to access your facility dashboard.
          </p>

          {/* Facility selector */}
          <div className="mb-6">
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
              Target Facility
            </label>
            <div className="flex gap-2">
              {['NFL', 'NCL', 'SLN'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFacility(f)}
                  className="flex-1 py-2 rounded text-sm font-semibold transition-all"
                  style={{
                    background: facility === f ? 'var(--primary)' : 'var(--card)',
                    color: facility === f ? '#fff' : 'var(--muted-foreground)',
                    border: `1px solid ${facility === f ? 'var(--primary)' : 'var(--border)'}`,
                    fontFamily: 'Barlow Condensed, sans-serif',
                    fontSize: 15,
                    letterSpacing: '0.06em',
                  }}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Tab switcher */}
          <div
            className="flex rounded-lg p-1 mb-6"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            {(['sso', 'guest'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className="flex-1 py-2 px-4 rounded text-sm font-medium transition-all"
                style={{
                  background: tab === t ? '#fff' : 'transparent',
                  color: tab === t ? 'var(--primary)' : 'var(--muted-foreground)',
                  boxShadow: tab === t ? '0 1px 4px rgba(0,0,0,0.08)' : 'none',
                }}
              >
                {t === 'sso' ? 'Institutional Login' : 'External Partner'}
              </button>
            ))}
          </div>

          {tab === 'sso' ? (
            <div className="space-y-3">
              <button
                onClick={() => handleSSO('standard')}
                disabled={loading}
                className="w-full py-3 px-4 rounded-lg font-semibold text-white transition-all hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-3"
                style={{ background: 'var(--primary)', fontSize: 15 }}
              >
                {loading ? (
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="white" strokeWidth="3" strokeDasharray="40" strokeDashoffset="10" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
                    <path d="M12 6v6l4 2"/>
                  </svg>
                )}
                Login with Institutional Identity
              </button>
              <div style={{ color: 'var(--muted-foreground)', fontSize: 12, textAlign: 'center' }}>
                Redirects to ICFO Shibboleth SSO
              </div>

              {/* Demo role shortcuts */}
              <div className="mt-6 pt-6" style={{ borderTop: '1px solid var(--border)' }}>
                <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginBottom: 10, textAlign: 'center', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 600 }}>
                  Demo Access
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Standard User', role: 'standard' as const, desc: 'PhD / Postdoc' },
                    { label: 'Super User', role: 'superuser' as const, desc: 'Tech Lead' },
                    { label: 'Super Admin', role: 'admin' as const, desc: 'Facility Mgr' },
                  ].map((r) => (
                    <button
                      key={r.role}
                      onClick={() => handleSSO(r.role)}
                      className="py-2 px-2 rounded-lg text-center transition-all hover:border-primary"
                      style={{
                        border: '1px solid var(--border)',
                        background: 'var(--card)',
                        cursor: 'pointer',
                      }}
                    >
                      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--primary)', fontFamily: 'Barlow Condensed, sans-serif', letterSpacing: '0.05em' }}>
                        {r.label}
                      </div>
                      <div style={{ fontSize: 10, color: 'var(--muted-foreground)', marginTop: 2 }}>{r.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <form onSubmit={handleGuestSubmit} className="space-y-4">
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
                  Institutional Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="researcher@university.edu"
                  required
                  className="w-full px-4 py-3 rounded-lg outline-none transition-all"
                  style={{
                    border: '1px solid var(--border)',
                    background: 'var(--card)',
                    fontSize: 15,
                    color: 'var(--foreground)',
                  }}
                  onFocus={(e) => (e.currentTarget.style.borderColor = 'var(--primary)')}
                  onBlur={(e) => (e.currentTarget.style.borderColor = 'var(--border)')}
                />
              </div>
              <p style={{ fontSize: 13, color: 'var(--muted-foreground)' }}>
                A magic link will be sent to your email. Valid for 24 hours.
              </p>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-lg font-semibold transition-all hover:opacity-90 disabled:opacity-60"
                style={{ background: 'var(--accent)', color: 'var(--accent-foreground)', fontSize: 15 }}
              >
                {loading ? 'Sending magic link…' : 'Send Magic Link'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
