import { useState } from 'react';
import type { Tool } from './Equipment';

interface BookingConfigProps {
  tool: Tool;
  date: string;
  start: string;
  end: string;
  onContinue: (support: string, supportRate: number, cost: number) => void;
}

const SUPPORT = [
  { id: 'autonomous', label: 'Autonomous', rate: 0, desc: 'Self-operated session, no facility staff required.' },
  { id: 'technician', label: 'Technician Support', rate: 40, desc: 'A facility technician will assist with setup and operation.' },
  { id: 'supervisor', label: 'Supervisor Support', rate: 60, desc: 'Full supervision by a senior facility staff member.' },
];

export default function BookingConfig({ tool, date, start, end, onContinue }: BookingConfigProps) {
  const [support, setSupport] = useState('autonomous');

  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  const hours = Math.max(1, (eh * 60 + em - (sh * 60 + sm)) / 60);

  const supportRate = SUPPORT.find((s) => s.id === support)?.rate ?? 0;
  const machineCost = tool.rate * hours;
  const supportCost = supportRate * hours;
  const total = machineCost + supportCost;

  return (
    <div className="max-w-lg mx-auto space-y-5">
      {/* Title */}
      <div>
        <h1 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 26, fontWeight: 700, color: 'var(--primary)', marginBottom: 4 }}>
          Book {tool.name}
        </h1>
        <div style={{ fontSize: 14, color: 'var(--muted-foreground)' }}>Configure your session details below.</div>
      </div>

      {/* Session summary */}
      <div
        className="rounded-xl p-5 space-y-3"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        {[
          { label: 'Date', value: date },
          { label: 'Time', value: `${start} – ${end}` },
          { label: 'Duration', value: `${hours} hour${hours !== 1 ? 's' : ''}` },
        ].map((row) => (
          <div key={row.label} className="flex items-center justify-between">
            <span style={{ fontSize: 13, color: 'var(--muted-foreground)', fontWeight: 500 }}>{row.label}</span>
            <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--foreground)', fontFamily: 'JetBrains Mono, monospace' }}>{row.value}</span>
          </div>
        ))}
      </div>

      {/* Support selection */}
      <div>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--foreground)', marginBottom: 10 }}>
          How much support do you need?
        </div>
        <div className="space-y-2">
          {SUPPORT.map((s) => (
            <label
              key={s.id}
              className="flex items-start gap-4 p-4 rounded-xl cursor-pointer transition-all"
              style={{
                border: `2px solid ${support === s.id ? 'var(--primary)' : 'var(--border)'}`,
                background: support === s.id ? 'var(--card)' : '#fff',
              }}
            >
              <input
                type="radio"
                name="support"
                value={s.id}
                checked={support === s.id}
                onChange={() => setSupport(s.id)}
                style={{ accentColor: 'var(--primary)', marginTop: 2 }}
              />
              <div className="flex-1">
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--foreground)' }}>{s.label}</div>
                <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 2 }}>{s.desc}</div>
              </div>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 15, fontWeight: 600, color: s.rate === 0 ? 'var(--muted-foreground)' : 'var(--foreground)', whiteSpace: 'nowrap', paddingTop: 2 }}>
                {s.rate === 0 ? '€0/h' : `+€${s.rate}/h`}
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Cost estimate */}
      <div
        className="rounded-xl p-5 space-y-3"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          Estimated Cost
        </div>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span style={{ fontSize: 14, color: 'var(--muted-foreground)' }}>Machine ({hours}h × €{tool.rate}/h)</span>
            <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14, fontWeight: 500 }}>€{machineCost.toFixed(0)}</span>
          </div>
          <div className="flex justify-between">
            <span style={{ fontSize: 14, color: 'var(--muted-foreground)' }}>Support</span>
            <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14, fontWeight: 500 }}>
              {supportCost === 0 ? '€0' : `€${supportCost.toFixed(0)}`}
            </span>
          </div>
          <div style={{ height: 1, background: 'var(--border)' }} />
          <div className="flex justify-between">
            <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--primary)' }}>Estimated total</span>
            <span style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 26, fontWeight: 700, color: 'var(--primary)' }}>
              €{total.toFixed(0)}
            </span>
          </div>
        </div>
        <div style={{ fontSize: 11, color: 'var(--muted-foreground)', paddingTop: 4 }}>
          Final cost confirmed on booking. Charged to selected research grant.
        </div>
      </div>

      <button
        onClick={() => onContinue(support, supportRate, total)}
        className="w-full py-4 rounded-xl font-semibold text-white text-base transition-all hover:opacity-90"
        style={{ background: 'var(--primary)' }}
      >
        Choose grant →
      </button>
    </div>
  );
}
