import { useState } from 'react';
import type { Tool } from './Equipment';

interface EquipmentDetailProps {
  tool: Tool;
  onCheckAvailability: () => void;
  onGoToTraining: () => void;
}

const CERT_STEPS = [
  { key: 'account', label: 'Account verified' },
  { key: 'sop', label: 'SOP completed' },
  { key: 'quiz', label: 'Quiz passed — 94%' },
  { key: 'practical', label: 'Practical assessment approved' },
];

const CERT_PROGRESS: Record<string, number> = {
  certified: 4,
  'assessment-required': 3,
  'quiz-required': 2,
  'not-started': 0,
};

export default function EquipmentDetail({ tool, onCheckAvailability, onGoToTraining }: EquipmentDetailProps) {
  const [tab, setTab] = useState<'overview' | 'requirements' | 'pricing'>('overview');

  const stepsCompleted = CERT_PROGRESS[tool.certStatus];

  const STATUS_CONFIG = {
    operational: { label: 'Available', color: '#10B981' },
    maintenance: { label: 'Under Maintenance', color: '#F59E0B' },
    offline: { label: 'Offline', color: '#EF4444' },
    active: { label: 'In Use', color: '#8B5CF6' },
  };
  const sc = STATUS_CONFIG[tool.status];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Hero */}
      <div
        className="rounded-2xl p-6"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 28, fontWeight: 700, color: 'var(--primary)', lineHeight: 1.1, marginBottom: 4 }}>
              {tool.name}
            </h1>
            <div style={{ fontSize: 14, color: 'var(--muted-foreground)', marginBottom: 10 }}>
              {tool.facility} · {tool.category}
            </div>
            <p style={{ fontSize: 15, color: 'var(--foreground)', lineHeight: 1.6 }}>
              {tool.description}
            </p>
          </div>
          <div className="flex flex-col items-end gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: sc.color }} />
              <span style={{ fontSize: 14, fontWeight: 600, color: sc.color }}>{sc.label}</span>
            </div>
            <div style={{ fontSize: 13, color: 'var(--muted-foreground)', textAlign: 'right' }}>
              Next available<br />
              <strong style={{ color: 'var(--foreground)' }}>{tool.nextAvailable}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div
        className="flex gap-1 p-1 rounded-xl"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'requirements', label: 'Requirements' },
          { id: 'pricing', label: 'Pricing' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id as typeof tab)}
            className="flex-1 py-2 rounded-lg text-sm font-medium transition-all"
            style={{
              background: tab === t.id ? 'var(--primary)' : 'transparent',
              color: tab === t.id ? '#fff' : 'var(--muted-foreground)',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {tab === 'overview' && (
        <div
          className="rounded-xl p-6 space-y-5"
          style={{ background: '#fff', border: '1px solid var(--border)' }}
        >
          {[
            {
              title: 'Capabilities',
              items: {
                'HDB-MLA150': ['Direct-write lithography (100 nm resolution)', 'Grayscale patterning', 'Large-area uniformity < 5% CD variation', 'Substrates up to 6" wafers'],
                'RIE-OXFORD': ['Anisotropic etch profiles', 'SF₆/CHF₃/Cl₂ chemistry library', 'Endpoint detection', '< 5% non-uniformity across 4" wafer'],
                'EBL-CRESTEC': ['Sub-10 nm feature resolution', 'Multi-layer registration < 5 nm', 'GDSII and OASIS input', 'HV & LV beam modes'],
              }[tool.code] ?? ['High-precision operation', 'Research-grade performance', 'Full staff support available'],
            },
            {
              title: 'Sample Requirements',
              items: {
                'HDB-MLA150': ['Max substrate: 200 × 200 mm', 'Max resist thickness: 10 μm', 'Clean, dry surface required', 'No ferromagnetic materials'],
                'RIE-OXFORD': ['Max wafer size: 4 inches', 'No wet samples', 'Sample mounting required for small pieces', 'Surface must be free of organics'],
                'EBL-CRESTEC': ['Conducting or coated substrate', 'Max height: 5 mm', 'Min surface resistivity < 10⁶ Ω/□', 'Pre-bake resist before loading'],
              }[tool.code] ?? ['Contact facility staff for requirements', 'Clean room protocols apply', 'Pre-booking consultation recommended'],
            },
          ].map((section) => (
            <div key={section.title}>
              <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>
                {section.title}
              </div>
              <ul className="space-y-1.5">
                {section.items.map((item, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span style={{ color: 'var(--primary)', marginTop: 2, fontSize: 12 }}>—</span>
                    <span style={{ fontSize: 14, color: 'var(--foreground)', lineHeight: 1.5 }}>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      {tab === 'requirements' && (
        <div className="space-y-4">
          {/* YOUR ACCESS */}
          <div
            className="rounded-xl p-6"
            style={{ background: '#fff', border: '1px solid var(--border)' }}
          >
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 16 }}>
              Your Access
            </div>
            <div className="space-y-3">
              {CERT_STEPS.map((step, i) => {
                const done = i < stepsCompleted;
                const current = i === stepsCompleted;
                return (
                  <div key={step.key} className="flex items-center gap-3">
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-xs font-bold"
                      style={{
                        background: done ? '#10B981' : current ? 'var(--accent)' : 'var(--muted)',
                        color: done ? '#fff' : current ? 'var(--primary)' : 'var(--muted-foreground)',
                      }}
                    >
                      {done ? '✓' : i + 1}
                    </div>
                    <span
                      style={{
                        fontSize: 14,
                        color: done ? 'var(--foreground)' : 'var(--muted-foreground)',
                        fontWeight: done || current ? 500 : 400,
                      }}
                    >
                      {step.label}
                    </span>
                    {current && (
                      <span
                        className="ml-auto px-2 py-0.5 rounded text-xs font-semibold"
                        style={{ background: '#FEF3C7', color: '#92400E' }}
                      >
                        Next step
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {tool.certified ? (
              <div
                className="mt-5 p-4 rounded-xl flex items-center gap-3"
                style={{ background: '#D1FAE5', border: '1px solid #A7F3D0' }}
              >
                <span style={{ fontSize: 20 }}>✅</span>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: '#065F46' }}>You are certified to use this equipment.</div>
                  <div style={{ fontSize: 12, color: '#047857', marginTop: 2 }}>No further steps required.</div>
                </div>
              </div>
            ) : (
              <div
                className="mt-5 p-4 rounded-xl"
                style={{ background: '#FEF3C7', border: '1px solid #FDE68A' }}
              >
                <div style={{ fontSize: 14, fontWeight: 600, color: '#92400E', marginBottom: 4 }}>
                  {tool.certStatus === 'assessment-required'
                    ? 'Complete your practical assessment to gain full access.'
                    : tool.certStatus === 'quiz-required'
                    ? 'Pass the online quiz to unlock booking.'
                    : 'Complete training to access this instrument.'}
                </div>
                <button
                  onClick={onGoToTraining}
                  className="mt-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all hover:opacity-90"
                  style={{ background: 'var(--primary)', color: '#fff' }}
                >
                  {tool.certStatus === 'assessment-required' ? 'Request practical assessment' : 'Start training →'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'pricing' && (
        <div
          className="rounded-xl p-6 space-y-5"
          style={{ background: '#fff', border: '1px solid var(--border)' }}
        >
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>
              Base Rate
            </div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 40, fontWeight: 700, color: 'var(--primary)', lineHeight: 1 }}>
              €{tool.rate}
            </div>
            <div style={{ fontSize: 14, color: 'var(--muted-foreground)', marginTop: 4 }}>per hour · charged to your research grant</div>
          </div>

          <div style={{ height: 1, background: 'var(--border)' }} />

          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 12 }}>
              Support Options
            </div>
            <div className="space-y-2">
              {[
                { label: 'Autonomous', rate: 0, desc: 'Self-operated session — no facility staff' },
                { label: 'Technician Support', rate: 40, desc: 'A technician assists with setup and operation' },
                { label: 'Supervisor Support', rate: 60, desc: 'Full supervision by senior staff member' },
              ].map((s) => (
                <div
                  key={s.label}
                  className="flex items-center gap-4 p-4 rounded-xl"
                  style={{ border: '1px solid var(--border)', background: 'var(--card)' }}
                >
                  <div className="flex-1">
                    <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--foreground)' }}>{s.label}</div>
                    <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 2 }}>{s.desc}</div>
                  </div>
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 15, fontWeight: 600, color: s.rate === 0 ? 'var(--muted-foreground)' : 'var(--foreground)', whiteSpace: 'nowrap' }}>
                    {s.rate === 0 ? '€0 / h' : `+€${s.rate} / h`}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* CTA */}
      <div className="flex gap-3">
        {tool.certified ? (
          <button
            onClick={onCheckAvailability}
            className="flex-1 py-4 rounded-xl font-semibold text-white text-base transition-all hover:opacity-90"
            style={{ background: 'var(--primary)' }}
          >
            Check availability →
          </button>
        ) : (
          <>
            <button
              onClick={onGoToTraining}
              className="flex-1 py-4 rounded-xl font-semibold text-base transition-all hover:opacity-90"
              style={{ border: '2px solid var(--primary)', color: 'var(--primary)' }}
            >
              View training →
            </button>
            {tool.certStatus === 'assessment-required' && (
              <button
                onClick={onCheckAvailability}
                className="flex-1 py-4 rounded-xl font-semibold text-base transition-all hover:opacity-90"
                style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}
                disabled
              >
                Booking locked
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}
