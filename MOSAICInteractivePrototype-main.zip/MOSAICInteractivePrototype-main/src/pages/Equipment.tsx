import { useState } from 'react';
import type { Page } from '../components/Shell';

export interface Tool {
  id: string;
  name: string;
  code: string;
  facility: 'NFL' | 'NCL' | 'SLN';
  category: string;
  description: string;
  status: 'operational' | 'maintenance' | 'offline' | 'active';
  rate: number;
  certified: boolean;
  certStatus: 'certified' | 'assessment-required' | 'quiz-required' | 'not-started';
  nextAvailable: string;
  availableToday: boolean;
}

export const TOOLS: Tool[] = [
  {
    id: 't1',
    name: 'Heidelberg MLA 150',
    code: 'HDB-MLA150',
    facility: 'NFL',
    category: 'Photolithography',
    description: 'Maskless lithography system for high-resolution patterning.',
    status: 'operational',
    rate: 95,
    certified: true,
    certStatus: 'certified',
    nextAvailable: 'Tomorrow · 09:00',
    availableToday: true,
  },
  {
    id: 't2',
    name: 'Oxford Instruments RIE',
    code: 'RIE-OXFORD',
    facility: 'NFL',
    category: 'Etching',
    description: 'Reactive ion etching for precise pattern transfer.',
    status: 'operational',
    rate: 140,
    certified: true,
    certStatus: 'certified',
    nextAvailable: 'Today · 16:00',
    availableToday: true,
  },
  {
    id: 't3',
    name: 'EBL CRESTEC CABL-9000C',
    code: 'EBL-CRESTEC',
    facility: 'NFL',
    category: 'Lithography',
    description: 'Electron beam lithography for sub-10nm resolution features.',
    status: 'operational',
    rate: 180,
    certified: false,
    certStatus: 'assessment-required',
    nextAvailable: 'Tomorrow · 14:00',
    availableToday: false,
  },
  {
    id: 't4',
    name: 'FIB Zeiss Orion NanoFab',
    code: 'FIB-ORION',
    facility: 'NFL',
    category: 'Ion Beam',
    description: 'Focused ion beam for nanoscale milling and deposition.',
    status: 'maintenance',
    rate: 133.70,
    certified: false,
    certStatus: 'not-started',
    nextAvailable: '25 Sep · 09:00',
    availableToday: false,
  },
  {
    id: 't5',
    name: 'ALD Beneq TFS-200',
    code: 'ALD-BENEQ',
    facility: 'NFL',
    category: 'Deposition',
    description: 'Atomic layer deposition for conformal thin film growth.',
    status: 'operational',
    rate: 58,
    certified: false,
    certStatus: 'quiz-required',
    nextAvailable: 'Today · 15:30',
    availableToday: true,
  },
  {
    id: 't6',
    name: 'JEOL SEM 7000F',
    code: 'SEM-JEOL',
    facility: 'NCL',
    category: 'Characterization',
    description: 'High-resolution scanning electron microscope with EDS.',
    status: 'operational',
    rate: 72,
    certified: true,
    certStatus: 'certified',
    nextAvailable: 'Today · 13:00',
    availableToday: true,
  },
  {
    id: 't7',
    name: 'Leica TCS SP8 STED',
    code: 'SLN-STED',
    facility: 'SLN',
    category: 'Microscopy',
    description: 'Stimulated emission depletion super-resolution microscopy.',
    status: 'operational',
    rate: 110,
    certified: false,
    certStatus: 'not-started',
    nextAvailable: 'Tomorrow · 10:00',
    availableToday: false,
  },
  {
    id: 't8',
    name: 'Asylum MFP-3D AFM',
    code: 'AFM-MFP3D',
    facility: 'NCL',
    category: 'Characterization',
    description: 'Atomic force microscope for surface topography and force measurement.',
    status: 'operational',
    rate: 85,
    certified: true,
    certStatus: 'certified',
    nextAvailable: 'Today · 11:00',
    availableToday: true,
  },
];

const STATUS_CONFIG = {
  operational: { label: 'Available', color: '#10B981', bg: '#D1FAE5' },
  maintenance: { label: 'Maintenance', color: '#F59E0B', bg: '#FEF3C7' },
  offline: { label: 'Offline', color: '#EF4444', bg: '#FEE2E2' },
  active: { label: 'In Use', color: '#8B5CF6', bg: '#EDE9FE' },
};

const CERT_CONFIG = {
  certified: { label: '✓ You are certified', color: '#10B981', bg: '#D1FAE5' },
  'assessment-required': { label: '⚠ Practical assessment required', color: '#F59E0B', bg: '#FEF3C7' },
  'quiz-required': { label: '○ Complete quiz to access', color: '#6366F1', bg: '#EEF2FF' },
  'not-started': { label: '○ Training not started', color: '#9CA3AF', bg: '#F3F4F6' },
};

const FACILITIES = ['All', 'NFL', 'NCL', 'SLN'];
const FILTERS = ['Availability', 'Certified only', 'Cost'];

interface EquipmentProps {
  onSelectTool: (tool: Tool) => void;
  onNavigate: (page: Page) => void;
}

export default function Equipment({ onSelectTool, onNavigate }: EquipmentProps) {
  const [facility, setFacility] = useState('All');
  const [search, setSearch] = useState('');
  const [certifiedOnly, setCertifiedOnly] = useState(false);
  const [availableOnly, setAvailableOnly] = useState(false);

  const filtered = TOOLS.filter((t) => {
    const matchFac = facility === 'All' || t.facility === facility;
    const matchSearch =
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.category.toLowerCase().includes(search.toLowerCase()) ||
      t.description.toLowerCase().includes(search.toLowerCase());
    const matchCert = !certifiedOnly || t.certified;
    const matchAvail = !availableOnly || t.availableToday;
    return matchFac && matchSearch && matchCert && matchAvail;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      {/* Search + filters */}
      <div className="space-y-3">
        <div className="relative">
          <svg className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--muted-foreground)' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search equipment, capability or technique…"
            className="w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none"
            style={{ background: '#fff', border: '1px solid var(--border)', fontSize: 14 }}
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {/* Facility tabs */}
          <div
            className="flex gap-1 p-1 rounded-xl"
            style={{ background: '#fff', border: '1px solid var(--border)' }}
          >
            {FACILITIES.map((f) => (
              <button
                key={f}
                onClick={() => setFacility(f)}
                className="px-4 py-1.5 rounded-lg text-sm font-medium transition-all"
                style={{
                  background: facility === f ? 'var(--primary)' : 'transparent',
                  color: facility === f ? '#fff' : 'var(--muted-foreground)',
                  fontFamily: facility === f ? 'Barlow Condensed, sans-serif' : undefined,
                  letterSpacing: facility === f ? '0.06em' : undefined,
                }}
              >
                {f}
              </button>
            ))}
          </div>

          <button
            onClick={() => setAvailableOnly(!availableOnly)}
            className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5"
            style={{
              background: availableOnly ? '#D1FAE5' : '#fff',
              color: availableOnly ? '#065F46' : 'var(--muted-foreground)',
              border: `1px solid ${availableOnly ? '#10B981' : 'var(--border)'}`,
            }}
          >
            <span className="w-2 h-2 rounded-full" style={{ background: '#10B981' }} />
            Available today
          </button>

          <button
            onClick={() => setCertifiedOnly(!certifiedOnly)}
            className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
            style={{
              background: certifiedOnly ? '#E6EBF5' : '#fff',
              color: certifiedOnly ? 'var(--primary)' : 'var(--muted-foreground)',
              border: `1px solid ${certifiedOnly ? 'var(--primary)' : 'var(--border)'}`,
            }}
          >
            ✓ Certified only
          </button>

          <div className="ml-auto" style={{ fontSize: 13, color: 'var(--muted-foreground)' }}>
            {filtered.length} instruments
          </div>
        </div>
      </div>

      {/* Equipment cards */}
      <div className="space-y-3">
        {filtered.map((tool) => {
          const sc = STATUS_CONFIG[tool.status];
          const cc = CERT_CONFIG[tool.certStatus];
          return (
            <div
              key={tool.id}
              className="rounded-xl p-5 transition-all cursor-pointer"
              style={{ background: '#fff', border: '1px solid var(--border)' }}
              onClick={() => onSelectTool(tool)}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'var(--primary)')}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'var(--border)')}
            >
              <div className="flex items-start gap-4">
                {/* Left: info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 flex-wrap mb-1">
                    <span style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 18, fontWeight: 700, color: 'var(--primary)' }}>
                      {tool.name}
                    </span>
                    <span
                      className="px-2 py-0.5 rounded-full text-xs font-semibold"
                      style={{ background: sc.bg, color: sc.color }}
                    >
                      {sc.label}
                    </span>
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--muted-foreground)', marginBottom: 8 }}>
                    {tool.facility} · {tool.category}
                  </div>
                  <div style={{ fontSize: 14, color: 'var(--foreground)', lineHeight: 1.5 }}>
                    {tool.description}
                  </div>

                  {/* Cert badge */}
                  <div
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg mt-3 text-xs font-semibold"
                    style={{ background: cc.bg, color: cc.color }}
                  >
                    {cc.label}
                  </div>
                </div>

                {/* Right: pricing + action */}
                <div className="flex flex-col items-end gap-3 shrink-0">
                  <div className="text-right">
                    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 22, fontWeight: 700, color: 'var(--primary)', lineHeight: 1 }}>
                      €{tool.rate}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--muted-foreground)' }}>/ hour</div>
                  </div>

                  <div className="text-right">
                    {tool.availableToday && (
                      <div style={{ fontSize: 12, color: '#10B981', fontWeight: 600, marginBottom: 2 }}>Available today</div>
                    )}
                    <div style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>
                      Next: {tool.nextAvailable}
                    </div>
                  </div>

                  <button
                    onClick={(e) => { e.stopPropagation(); onSelectTool(tool); }}
                    className="px-5 py-2 rounded-xl text-sm font-semibold transition-all hover:opacity-90"
                    style={{ background: 'var(--primary)', color: '#fff' }}
                  >
                    View equipment
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filtered.length === 0 && (
          <div className="text-center py-16" style={{ color: 'var(--muted-foreground)' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🔬</div>
            <div style={{ fontSize: 15, fontWeight: 500 }}>No equipment matches your filters</div>
            <div style={{ fontSize: 13, marginTop: 4 }}>Try adjusting the facility or clearing filters</div>
          </div>
        )}
      </div>
    </div>
  );
}
