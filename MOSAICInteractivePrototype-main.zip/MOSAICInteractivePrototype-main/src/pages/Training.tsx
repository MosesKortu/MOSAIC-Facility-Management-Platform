import { useState } from 'react';

interface Module {
  id: string;
  tool: string;
  code: string;
  facility: string;
  status: 'certified' | 'assessment-required' | 'in-progress' | 'not-started' | 'quiz-required';
  score?: number;
  sopVersion: string;
  sopReadTime: number; // minutes
  quizQuestions: { id: number; question: string; options: string[]; correct: number }[];
}

const MODULES: Module[] = [
  {
    id: 'm1',
    tool: 'Heidelberg MLA 150',
    code: 'HDB-MLA150',
    facility: 'NFL',
    status: 'certified',
    score: 94,
    sopVersion: 'v3.2',
    sopReadTime: 12,
    quizQuestions: [],
  },
  {
    id: 'm2',
    tool: 'Oxford Instruments RIE',
    code: 'RIE-OXFORD',
    facility: 'NFL',
    status: 'certified',
    score: 88,
    sopVersion: 'v2.1',
    sopReadTime: 8,
    quizQuestions: [],
  },
  {
    id: 'm3',
    tool: 'EBL CRESTEC CABL-9000C',
    code: 'EBL-CRESTEC',
    facility: 'NFL',
    status: 'assessment-required',
    score: 94,
    sopVersion: 'v4.0',
    sopReadTime: 20,
    quizQuestions: [
      { id: 1, question: 'What should you verify before starting the instrument?', options: ['Sample compatibility', 'Equipment status', 'Required PPE', 'All of the above'], correct: 3 },
      { id: 2, question: 'What is the minimum beam step size achievable with the CRESTEC system?', options: ['0.5 nm', '2 nm', '5 nm', '10 nm'], correct: 1 },
      { id: 3, question: 'Which resist type is recommended for sub-20nm features?', options: ['PMMA 950K', 'HSQ (Hydrogen Silsesquioxane)', 'ZEP-520A', 'ma-N 2403'], correct: 1 },
      { id: 4, question: 'Required chamber base pressure before exposure?', options: ['< 1×10⁻⁴ mbar', '< 5×10⁻⁵ mbar', '< 1×10⁻⁶ mbar', '< 5×10⁻⁷ mbar'], correct: 3 },
      { id: 5, question: 'Emergency stop: correct power-down order?', options: ['Column → Stage → Vacuum → Interlock', 'Interlock → Vacuum → Column → Stage', 'Stage → Column → Interlock → Vacuum', 'Vacuum → Stage → Column → Interlock'], correct: 0 },
    ],
  },
  {
    id: 'm4',
    tool: 'ALD Beneq TFS-200',
    code: 'ALD-BENEQ',
    facility: 'NFL',
    status: 'quiz-required',
    sopVersion: 'v1.5',
    sopReadTime: 10,
    quizQuestions: [
      { id: 1, question: 'What is the primary purpose of ALD (Atomic Layer Deposition)?', options: ['Pattern transfer', 'Conformal thin film growth', 'Surface cleaning', 'Sample imaging'], correct: 1 },
      { id: 2, question: 'What should you check before loading a sample?', options: ['Sample cleanliness', 'Precursor levels', 'Chamber temperature', 'All of the above'], correct: 3 },
    ],
  },
  {
    id: 'm5',
    tool: 'FIB Zeiss Orion NanoFab',
    code: 'FIB-ORION',
    facility: 'NFL',
    status: 'not-started',
    sopVersion: 'v2.3',
    sopReadTime: 18,
    quizQuestions: [],
  },
  {
    id: 'm6',
    tool: 'JEOL SEM 7000F',
    code: 'SEM-JEOL',
    facility: 'NCL',
    status: 'certified',
    score: 91,
    sopVersion: 'v3.0',
    sopReadTime: 9,
    quizQuestions: [],
  },
  {
    id: 'm7',
    tool: 'Asylum MFP-3D AFM',
    code: 'AFM-MFP3D',
    facility: 'NCL',
    status: 'certified',
    score: 85,
    sopVersion: 'v2.0',
    sopReadTime: 7,
    quizQuestions: [],
  },
  {
    id: 'm8',
    tool: 'Leica TCS SP8 STED',
    code: 'SLN-STED',
    facility: 'SLN',
    status: 'not-started',
    sopVersion: 'v1.8',
    sopReadTime: 15,
    quizQuestions: [],
  },
];

const STATUS_CONFIG = {
  certified: { label: 'Certified', color: '#10B981', bg: '#D1FAE5', pct: 100 },
  'assessment-required': { label: 'Assessment required', color: '#8B5CF6', bg: '#EDE9FE', pct: 75 },
  'in-progress': { label: 'In progress', color: '#F59E0B', bg: '#FEF3C7', pct: 50 },
  'quiz-required': { label: 'Quiz required', color: '#F59E0B', bg: '#FEF3C7', pct: 25 },
  'not-started': { label: 'Not started', color: '#9CA3AF', bg: '#F3F4F6', pct: 0 },
};

const TRAINING_STEPS = ['Read SOP', 'Safety Quiz', 'Practical Assessment', 'Certification'];
const STEP_BY_STATUS: Record<string, number> = {
  'not-started': 0,
  'quiz-required': 1,
  'assessment-required': 2,
  'in-progress': 2,
  certified: 4,
};

export default function Training() {
  const [modules, setModules] = useState(MODULES);
  const [activeModule, setActiveModule] = useState<Module | null>(null);
  const [step, setStep] = useState<'list' | 'sop' | 'quiz' | 'result' | 'assessment-request'>('list');
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [currentQ, setCurrentQ] = useState(0);
  const [acknowledged, setAcknowledged] = useState(false);

  const certified = modules.filter((m) => m.status === 'certified').length;
  const actionRequired = modules.filter((m) => m.status === 'assessment-required').length;
  const inProgress = modules.filter((m) => ['quiz-required', 'in-progress'].includes(m.status)).length;

  const openModule = (mod: Module) => {
    setActiveModule(mod);
    setStep('sop');
    setAnswers({});
    setCurrentQ(0);
    setAcknowledged(false);
  };

  const submitQuiz = () => {
    if (!activeModule) return;
    const correct = activeModule.quizQuestions.filter((q) => answers[q.id] === q.correct).length;
    const score = Math.round((correct / activeModule.quizQuestions.length) * 100);
    setModules((prev) =>
      prev.map((m) =>
        m.id === activeModule.id
          ? { ...m, score, status: score >= 80 ? 'assessment-required' : 'quiz-required' }
          : m
      )
    );
    setActiveModule((prev) => prev ? { ...prev, score } : null);
    setStep('result');
  };

  const quizScore = activeModule
    ? Math.round(
        (activeModule.quizQuestions.filter((q) => answers[q.id] === q.correct).length /
          Math.max(activeModule.quizQuestions.length, 1)) * 100
      )
    : 0;

  // Module list view
  if (step === 'list') {
    return (
      <div className="max-w-3xl mx-auto space-y-5">
        {/* Summary */}
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Certified', value: certified, color: '#10B981' },
            { label: 'In Progress', value: inProgress, color: '#F59E0B' },
            { label: 'Action Required', value: actionRequired, color: '#8B5CF6' },
          ].map((s) => (
            <div key={s.label} className="p-5 rounded-xl text-center" style={{ background: '#fff', border: '1px solid var(--border)' }}>
              <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 40, fontWeight: 700, color: s.color }}>{s.value}</div>
              <div style={{ fontSize: 12, color: 'var(--muted-foreground)', fontWeight: 500, marginTop: 4 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Action required callout */}
        {actionRequired > 0 && (
          <div
            className="p-5 rounded-xl flex items-start gap-4"
            style={{ background: '#EDE9FE', border: '2px solid #8B5CF6' }}
          >
            <span style={{ fontSize: 24 }}>🧪</span>
            <div className="flex-1">
              <div style={{ fontWeight: 700, color: '#5B21B6', fontSize: 14, marginBottom: 4 }}>
                EBL CRESTEC — Practical assessment required
              </div>
              <div style={{ fontSize: 13, color: '#6D28D9', lineHeight: 1.5 }}>
                You passed the required quiz (94%). Your next step is to complete a hands-on practical assessment with a facility supervisor.
              </div>
            </div>
            <button
              onClick={() => { openModule(modules.find((m) => m.status === 'assessment-required')!); setStep('assessment-request'); }}
              className="px-4 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90 shrink-0"
              style={{ background: '#7C3AED' }}
            >
              Request assessment
            </button>
          </div>
        )}

        {/* Module list */}
        <div className="space-y-3">
          {modules.map((mod) => {
            const sc = STATUS_CONFIG[mod.status];
            const stepsComplete = STEP_BY_STATUS[mod.status];
            return (
              <div
                key={mod.id}
                className="rounded-xl p-5 transition-all"
                style={{ background: '#fff', border: '1px solid var(--border)' }}
              >
                <div className="flex items-center gap-4">
                  {/* Progress indicator */}
                  <div className="relative shrink-0">
                    <svg width="48" height="48" viewBox="0 0 48 48">
                      <circle cx="24" cy="24" r="20" fill="none" stroke="var(--muted)" strokeWidth="4" />
                      <circle
                        cx="24" cy="24" r="20"
                        fill="none"
                        stroke={sc.color}
                        strokeWidth="4"
                        strokeDasharray={`${(sc.pct / 100) * 125.6} 125.6`}
                        strokeLinecap="round"
                        transform="rotate(-90 24 24)"
                      />
                    </svg>
                    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: sc.color }}>
                      {sc.pct}%
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 17, fontWeight: 700, color: 'var(--primary)' }}>
                      {mod.tool}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginBottom: 8 }}>{mod.facility}</div>

                    {/* Step strip */}
                    <div className="flex items-center gap-1.5">
                      {TRAINING_STEPS.map((s, i) => (
                        <div key={i} className="flex items-center gap-1.5">
                          <div
                            className="flex items-center justify-center text-xs rounded-full"
                            style={{
                              width: 18, height: 18,
                              background: i < stepsComplete ? '#10B981' : 'var(--muted)',
                              color: i < stepsComplete ? '#fff' : 'var(--muted-foreground)',
                              fontSize: 9, fontWeight: 700,
                            }}
                          >
                            {i < stepsComplete ? '✓' : i + 1}
                          </div>
                          <span style={{ fontSize: 10, color: i < stepsComplete ? '#10B981' : 'var(--muted-foreground)' }}>
                            {s}
                          </span>
                          {i < 3 && <div style={{ width: 12, height: 1, background: i < stepsComplete ? '#10B981' : 'var(--border)' }} />}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    {mod.score !== undefined && (
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 20, fontWeight: 700, color: mod.score >= 80 ? '#10B981' : '#EF4444' }}>
                          {mod.score}%
                        </div>
                        <div style={{ fontSize: 10, color: 'var(--muted-foreground)' }}>quiz</div>
                      </div>
                    )}
                    <span
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold"
                      style={{ background: sc.bg, color: sc.color, whiteSpace: 'nowrap' }}
                    >
                      {sc.label}
                    </span>
                    {(mod.status === 'quiz-required' || mod.status === 'not-started') && mod.quizQuestions.length > 0 && (
                      <button
                        onClick={() => openModule(mod)}
                        className="px-4 py-1.5 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90 shrink-0"
                        style={{ background: 'var(--primary)' }}
                      >
                        Start
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // SOP view
  if (step === 'sop' && activeModule) {
    return (
      <div className="max-w-3xl mx-auto space-y-5">
        {/* Progress strip */}
        <div className="flex items-center gap-3">
          {TRAINING_STEPS.map((s, i) => {
            const stepsComplete = STEP_BY_STATUS[activeModule.status];
            const done = i < stepsComplete;
            const current = i === stepsComplete;
            return (
              <div key={i} className="flex items-center gap-3 flex-1">
                <div className="flex items-center gap-2">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-sm font-bold"
                    style={{
                      background: done ? '#10B981' : current ? 'var(--primary)' : 'var(--muted)',
                      color: done || current ? '#fff' : 'var(--muted-foreground)',
                    }}
                  >
                    {done ? '✓' : i + 1}
                  </div>
                  <span style={{ fontSize: 12, fontWeight: current ? 700 : 400, color: done ? '#10B981' : current ? 'var(--primary)' : 'var(--muted-foreground)' }}>
                    {s}
                  </span>
                </div>
                {i < 3 && <div style={{ flex: 1, height: 1, background: done ? '#10B981' : 'var(--border)' }} />}
              </div>
            );
          })}
        </div>

        {/* SOP Card */}
        <div className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
          <div className="p-5 flex items-center justify-between" style={{ background: 'var(--primary)', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
            <div>
              <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 20, fontWeight: 700, color: '#fff' }}>
                {activeModule.tool}
              </div>
              <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 2 }}>Standard Operating Procedure</div>
            </div>
            <div className="text-right">
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: 'var(--accent)', fontWeight: 700 }}>
                {activeModule.sopVersion}
              </div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 1 }}>
                Updated 14 Sep 2026
              </div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>
                ~{activeModule.sopReadTime} min read
              </div>
            </div>
          </div>

          <div className="p-6 space-y-6" style={{ background: '#fff' }}>
            {[
              { num: '01', title: 'System Overview & Safety', body: `The ${activeModule.tool} operates under strict cleanroom conditions. All users must be wearing appropriate PPE (cleanroom suit, gloves, mask, shoe covers) before entering the instrument bay. The system operates at ultra-high vacuum or controlled pressure conditions — never attempt to open the chamber without explicit authorization.` },
              { num: '02', title: 'Pre-Session Checklist', body: 'Verify your MOSAIC booking is active before entering the bay. Review the instrument logbook for outstanding issues from the previous session. Check all readings are within nominal range on the system status display. If any parameter is out of specification, do not proceed — contact the duty technician immediately.' },
              { num: '03', title: 'Sample Preparation & Loading', body: 'Ensure your sample is clean, dry, and compatible with instrument specifications. Use the sample preparation station in the anteroom — optical inspection is mandatory. Follow the loading procedure exactly as documented in the quick reference card posted at the instrument. Never force samples or exceed the weight/dimension limits.' },
              { num: '04', title: 'Operation Guidelines', body: 'Follow the step-by-step operation sequence. Never leave the instrument unattended during critical phases. Log any anomalies immediately in the instrument logbook and notify facility staff. If in doubt, stop and call the duty supervisor — incorrect operation can damage both equipment and samples.' },
              { num: '05', title: 'Emergency Procedures', body: 'In case of emergency: press the red emergency stop button on the control panel → the MOSAIC system will log the event → contact the duty supervisor via the emergency extension posted at the bay entrance. For fire or chemical spill emergencies, follow the facility evacuation procedure posted on all bay doors.' },
            ].map((section) => (
              <div key={section.num}>
                <div className="flex items-baseline gap-3 mb-3">
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, fontWeight: 700, color: 'var(--accent)', background: 'var(--primary)', padding: '2px 8px', borderRadius: 4 }}>
                    {section.num}
                  </span>
                  <h3 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 18, fontWeight: 700, color: 'var(--primary)' }}>
                    {section.title}
                  </h3>
                </div>
                <p style={{ fontSize: 14, color: 'var(--foreground)', lineHeight: 1.75, paddingLeft: 2 }}>{section.body}</p>
              </div>
            ))}

            {/* Acknowledge */}
            <div
              className="p-4 rounded-xl"
              style={{ background: 'var(--card)', border: `2px solid ${acknowledged ? '#10B981' : 'var(--border)'}` }}
            >
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={acknowledged}
                  onChange={(e) => setAcknowledged(e.target.checked)}
                  className="mt-0.5"
                  style={{ accentColor: '#10B981', width: 18, height: 18 }}
                />
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--foreground)' }}>I have read and understood this SOP</div>
                  <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 2 }}>
                    By acknowledging, you confirm that you will operate this equipment according to the procedures described above.
                  </div>
                </div>
              </label>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => { setStep('list'); setActiveModule(null); }}
                className="px-4 py-2 rounded-lg text-sm transition-all"
                style={{ border: '1px solid var(--border)', color: 'var(--muted-foreground)' }}
              >
                ← Back
              </button>
              <button
                onClick={() => setStep('quiz')}
                disabled={!acknowledged || activeModule.quizQuestions.length === 0}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90 disabled:opacity-40"
                style={{ background: 'var(--primary)' }}
              >
                {activeModule.quizQuestions.length > 0 ? 'Proceed to quiz →' : 'No quiz required for this module'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Quiz
  if (step === 'quiz' && activeModule) {
    const q = activeModule.quizQuestions[currentQ];
    const total = activeModule.quizQuestions.length;
    return (
      <div className="max-w-2xl mx-auto space-y-5">
        {/* Progress */}
        <div>
          <div className="flex justify-between mb-2">
            <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--primary)' }}>
              Question {currentQ + 1} of {total}
            </span>
            <span style={{ fontSize: 13, color: 'var(--muted-foreground)' }}>
              {Object.keys(answers).length} answered
            </span>
          </div>
          <div style={{ height: 6, background: 'var(--muted)', borderRadius: 3, overflow: 'hidden' }}>
            <div
              style={{
                height: '100%',
                width: `${((currentQ + 1) / total) * 100}%`,
                background: 'var(--primary)',
                borderRadius: 3,
                transition: 'width 0.3s ease',
              }}
            />
          </div>
        </div>

        <div className="rounded-xl p-8" style={{ background: '#fff', border: '1px solid var(--border)' }}>
          <h3 style={{ fontSize: 18, fontWeight: 600, color: 'var(--foreground)', lineHeight: 1.5, marginBottom: 24 }}>
            {q.question}
          </h3>

          <div className="space-y-3">
            {q.options.map((opt, i) => (
              <button
                key={i}
                onClick={() => setAnswers({ ...answers, [q.id]: i })}
                className="w-full text-left p-4 rounded-xl transition-all"
                style={{
                  border: `2px solid ${answers[q.id] === i ? 'var(--primary)' : 'var(--border)'}`,
                  background: answers[q.id] === i ? 'var(--card)' : '#fff',
                }}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 font-bold text-sm"
                    style={{
                      background: answers[q.id] === i ? 'var(--primary)' : 'var(--muted)',
                      color: answers[q.id] === i ? '#fff' : 'var(--muted-foreground)',
                    }}
                  >
                    {String.fromCharCode(65 + i)}
                  </div>
                  <span style={{ fontSize: 14, color: 'var(--foreground)' }}>{opt}</span>
                </div>
              </button>
            ))}
          </div>

          <div className="flex justify-between mt-8">
            <button
              onClick={() => setCurrentQ(Math.max(0, currentQ - 1))}
              disabled={currentQ === 0}
              className="px-5 py-2 rounded-lg text-sm disabled:opacity-40"
              style={{ border: '1px solid var(--border)', color: 'var(--muted-foreground)' }}
            >
              ← Previous
            </button>
            {currentQ < total - 1 ? (
              <button
                onClick={() => setCurrentQ(currentQ + 1)}
                disabled={answers[q.id] === undefined}
                className="px-6 py-2 rounded-lg text-sm font-semibold text-white disabled:opacity-40 transition-all hover:opacity-90"
                style={{ background: 'var(--primary)' }}
              >
                Next →
              </button>
            ) : (
              <button
                onClick={submitQuiz}
                disabled={answers[q.id] === undefined}
                className="px-6 py-2 rounded-lg text-sm font-semibold text-white disabled:opacity-40 transition-all hover:opacity-90"
                style={{ background: '#10B981' }}
              >
                Submit quiz
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Quiz result
  if (step === 'result' && activeModule) {
    const finalScore = activeModule.score ?? quizScore;
    const passed = finalScore >= 80;
    return (
      <div className="max-w-md mx-auto text-center py-8">
        <div
          className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6"
          style={{ background: passed ? '#D1FAE5' : '#FEE2E2' }}
        >
          {passed
            ? <svg className="w-12 h-12" style={{ color: '#10B981' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
            : <svg className="w-12 h-12" style={{ color: '#EF4444' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          }
        </div>

        <h2 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 28, fontWeight: 700, color: passed ? '#10B981' : '#EF4444', marginBottom: 8 }}>
          {passed ? 'Quiz Passed' : 'Quiz Failed'}
        </h2>

        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 60, fontWeight: 700, color: passed ? '#10B981' : '#EF4444', lineHeight: 1, marginBottom: 4 }}>
          {finalScore}%
        </div>
        <div style={{ fontSize: 14, color: 'var(--muted-foreground)', marginBottom: 8 }}>Required: 80%</div>

        {passed && (
          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8"
            style={{ background: '#D1FAE5', border: '1px solid #A7F3D0' }}
          >
            <svg className="w-4 h-4" style={{ color: '#10B981' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#065F46' }}>Training requirement completed</span>
          </div>
        )}

        {passed && (
          <div className="p-4 rounded-xl mb-6 text-left" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--primary)', marginBottom: 4 }}>Next step: Practical Assessment</div>
            <div style={{ fontSize: 13, color: 'var(--muted-foreground)', lineHeight: 1.5 }}>
              A practical evaluation request will be sent to your facility supervisor. You will be notified when your session is scheduled.
            </div>
          </div>
        )}

        <div className="flex gap-3">
          {!passed && (
            <button
              onClick={() => { setStep('sop'); setAnswers({}); setCurrentQ(0); setAcknowledged(false); }}
              className="flex-1 py-3 rounded-xl text-sm font-semibold text-white"
              style={{ background: 'var(--primary)' }}
            >
              Retry module
            </button>
          )}
          <button
            onClick={() => { setStep('list'); setActiveModule(null); }}
            className="flex-1 py-3 rounded-xl text-sm font-semibold"
            style={{ border: '1px solid var(--border)', color: 'var(--foreground)' }}
          >
            Back to training
          </button>
        </div>
      </div>
    );
  }

  // Assessment request
  if (step === 'assessment-request' && activeModule) {
    return (
      <div className="max-w-md mx-auto space-y-5">
        <h1 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 26, fontWeight: 700, color: 'var(--primary)' }}>
          Request Practical Assessment
        </h1>
        <div className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)', background: '#fff' }}>
          <div className="p-5" style={{ background: 'var(--primary)' }}>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 20, fontWeight: 700, color: '#fff' }}>{activeModule.tool}</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', marginTop: 2 }}>Quiz score: {activeModule.score}% · Passed</div>
          </div>
          <div className="p-5 space-y-4">
            <div style={{ fontSize: 14, color: 'var(--foreground)', lineHeight: 1.6 }}>
              You will be assessed by a facility supervisor on the following:
            </div>
            {['PPE compliance and cleanroom protocol', 'Instrument startup procedure', 'Sample loading and verification', 'Emergency stop procedure', 'Instrument shutdown and handover'].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded border-2 shrink-0" style={{ borderColor: 'var(--border)' }} />
                <span style={{ fontSize: 14, color: 'var(--foreground)' }}>{item}</span>
              </div>
            ))}
            <textarea
              placeholder="Optional: note preferred dates or times for your assessment…"
              rows={3}
              className="w-full px-4 py-3 rounded-lg text-sm outline-none resize-none"
              style={{ border: '1px solid var(--border)', background: 'var(--card)' }}
            />
          </div>
        </div>
        <button
          onClick={() => {
            alert('Assessment request submitted! You will receive an email when your session is confirmed.');
            setStep('list');
            setActiveModule(null);
          }}
          className="w-full py-4 rounded-xl font-semibold text-white transition-all hover:opacity-90"
          style={{ background: '#7C3AED', fontSize: 15 }}
        >
          Submit assessment request
        </button>
        <button
          onClick={() => { setStep('list'); setActiveModule(null); }}
          className="w-full py-2 text-sm"
          style={{ color: 'var(--muted-foreground)' }}
        >
          ← Back to training
        </button>
      </div>
    );
  }

  return null;
}
