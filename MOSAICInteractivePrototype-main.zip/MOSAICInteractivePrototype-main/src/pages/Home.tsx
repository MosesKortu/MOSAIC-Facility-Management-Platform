import type { Page } from '../components/Shell';

interface HomeProps {
  onNavigate: (page: Page, extra?: Record<string, unknown>) => void;
}

const HOUR = new Date().getHours();
const GREETING = HOUR < 12 ? 'Good morning' : HOUR < 17 ? 'Good afternoon' : 'Good evening';

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Hero search */}
      <div
        className="rounded-2xl p-8"
        style={{ background: 'var(--primary)' }}
      >
        <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 28, fontWeight: 700, color: '#fff', marginBottom: 4 }}>
          {GREETING}, Anna.
        </div>
        <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: 15, marginBottom: 20 }}>
          What are you working on today?
        </div>
        <div className="relative">
          <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'rgba(0,0,0,0.35)' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            placeholder="Search equipment, facility or capability…"
            className="w-full pl-10 pr-4 py-3.5 rounded-xl text-sm outline-none"
            style={{ background: '#fff', fontSize: 14 }}
            onFocus={(e) => onNavigate('equipment')}
            readOnly
          />
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-4 gap-3 mt-5">
          {[
            { label: 'Find equipment', icon: '🔬', page: 'equipment' as Page },
            { label: 'My bookings', icon: '📋', page: 'my-bookings' as Page },
            { label: 'Training', icon: '📖', page: 'training' as Page },
            { label: 'Grants', icon: '💶', page: 'grants' as Page },
          ].map((a) => (
            <button
              key={a.label}
              onClick={() => onNavigate(a.page)}
              className="py-3 px-3 rounded-xl text-center transition-all"
              style={{ background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.15)' }}
              onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.2)')}
              onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.12)')}
            >
              <div style={{ fontSize: 20, marginBottom: 4 }}>{a.icon}</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.85)', fontWeight: 500 }}>{a.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Main content grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Today's activity */}
        <div
          className="md:col-span-2 rounded-xl p-5"
          style={{ background: '#fff', border: '1px solid var(--border)' }}
        >
          <div className="flex items-center justify-between mb-4">
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.09em', textTransform: 'uppercase' }}>
              Today's Schedule
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>22 Sep 2026</div>
          </div>

          <div className="space-y-3">
            {[
              { time: '09:00', tool: 'Heidelberg MLA 150', facility: 'NFL', duration: '2 hours', status: 'upcoming', grant: 'EU-NANO-2026' },
              { time: '14:00', tool: 'Oxford RIE', facility: 'NFL', duration: '1 hour', status: 'confirmed', grant: 'EU-NANO-2026' },
            ].map((booking, i) => (
              <button
                key={i}
                onClick={() => onNavigate('my-bookings')}
                className="w-full flex items-center gap-4 p-4 rounded-xl text-left transition-all"
                style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'var(--primary)')}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'var(--border)')}
              >
                <div
                  className="flex flex-col items-center justify-center rounded-lg shrink-0"
                  style={{ width: 52, background: 'var(--primary)', color: '#fff', padding: '6px 4px' }}
                >
                  <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 20, fontWeight: 700, lineHeight: 1 }}>
                    {booking.time.split(':')[0]}
                  </div>
                  <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)' }}>:{booking.time.split(':')[1]}</div>
                </div>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--foreground)' }}>{booking.tool}</div>
                  <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 1 }}>
                    {booking.facility} · {booking.duration}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span
                    className="px-2 py-0.5 rounded-full text-xs font-semibold"
                    style={{
                      background: booking.status === 'upcoming' ? '#E6EBF5' : '#D1FAE5',
                      color: booking.status === 'upcoming' ? 'var(--primary)' : '#065F46',
                    }}
                  >
                    {booking.status === 'upcoming' ? 'Upcoming' : 'Confirmed'}
                  </span>
                  <span style={{ fontSize: 11, color: 'var(--muted-foreground)' }}>{booking.grant}</span>
                </div>
              </button>
            ))}

            <button
              onClick={() => onNavigate('equipment')}
              className="w-full py-3 rounded-xl text-sm font-semibold transition-all hover:opacity-90 mt-1"
              style={{ background: 'var(--primary)', color: '#fff' }}
            >
              + Book another session
            </button>
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Grant snapshot */}
          <div
            className="rounded-xl p-5"
            style={{ background: '#fff', border: '1px solid var(--border)' }}
          >
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.09em', textTransform: 'uppercase', marginBottom: 12 }}>
              Research Grants
            </div>
            <button
              onClick={() => onNavigate('grants')}
              className="w-full text-left"
            >
              <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 16, fontWeight: 700, color: 'var(--primary)' }}>
                EU-NANO-2026
              </div>
              <div
                className="flex items-center justify-between mt-3 mb-1.5"
              >
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 20, fontWeight: 700, color: 'var(--primary)' }}>€3,240</span>
                <span style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>remaining</span>
              </div>
              <div style={{ height: 6, background: 'var(--muted)', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{ width: '65%', height: '100%', background: 'var(--accent)', borderRadius: 3 }} />
              </div>
              <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginTop: 4 }}>€1,760 used of €5,000</div>
            </button>
          </div>

          {/* Your access */}
          <div
            className="rounded-xl p-5"
            style={{ background: '#fff', border: '1px solid var(--border)' }}
          >
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.09em', textTransform: 'uppercase', marginBottom: 12 }}>
              Your Access
            </div>
            <div className="space-y-2">
              {[
                { tool: 'Heidelberg MLA 150', status: 'certified' },
                { tool: 'Oxford RIE', status: 'certified' },
                { tool: 'EBL CRESTEC', status: 'action' },
              ].map((item) => (
                <button
                  key={item.tool}
                  onClick={() => onNavigate('training')}
                  className="w-full flex items-center gap-2 text-left"
                >
                  <span
                    className="text-xs"
                    style={{ color: item.status === 'certified' ? '#10B981' : '#F59E0B' }}
                  >
                    {item.status === 'certified' ? '✓' : '!'}
                  </span>
                  <span style={{ fontSize: 13, color: 'var(--foreground)', flex: 1 }}>{item.tool}</span>
                  {item.status === 'action' && (
                    <span style={{ fontSize: 11, color: '#F59E0B', fontWeight: 600 }}>Action needed</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Equipment status */}
      <div
        className="rounded-xl p-5"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.09em', textTransform: 'uppercase', marginBottom: 12 }}>
          Equipment Status
        </div>
        <div className="grid grid-cols-3 gap-4">
          {[
            { name: 'NFL', full: 'Nano Fabrication Lab', available: 12, maintenance: 2, offline: 0 },
            { name: 'NCL', full: 'Nanocharacterization Lab', available: 8, maintenance: 1, offline: 0 },
            { name: 'SLN', full: 'Super-res Light Microscopy', available: 7, maintenance: 0, offline: 0 },
          ].map((fac) => (
            <button
              key={fac.name}
              onClick={() => onNavigate('equipment')}
              className="p-4 rounded-xl text-left transition-all"
              style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'var(--primary)')}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'var(--border)')}
            >
              <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 18, fontWeight: 700, color: 'var(--primary)' }}>
                {fac.name}
              </div>
              <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginBottom: 10 }}>{fac.full}</div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: '#10B981' }} />
                  <span style={{ fontSize: 12, color: 'var(--foreground)' }}>{fac.available} available</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: '#F59E0B' }} />
                  <span style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>{fac.maintenance} maintenance</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
