import { useState, useEffect } from 'react';
import type { Page } from '../components/Shell';

interface ActiveSessionProps {
  onNavigate: (page: Page) => void;
}

export default function ActiveSession({ onNavigate }: ActiveSessionProps) {
  const [elapsed, setElapsed] = useState(42 * 60); // start at 42 min
  const [interlockState, setInterlockState] = useState<'connected' | 'disconnected'>('connected');
  const [powerState, setPowerState] = useState<'on' | 'off'>('on');
  const [ended, setEnded] = useState(false);

  const sessionEnd = 11 * 60; // 11:00 in minutes from midnight
  const sessionStart = 9 * 60; // 09:00
  const totalDuration = sessionEnd - sessionStart; // 120 min
  const remaining = totalDuration - elapsed;
  const ratePerMin = 95 / 60;
  const currentCost = ratePerMin * elapsed;

  useEffect(() => {
    if (ended) return;
    const t = setInterval(() => setElapsed((e) => Math.min(e + 1, totalDuration)), 1000);
    return () => clearInterval(t);
  }, [ended]);

  const fmt = (mins: number) => {
    const h = Math.floor(mins / 60);
    const m = Math.floor(mins % 60);
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m`;
  };

  if (ended) {
    return (
      <div className="max-w-lg mx-auto text-center py-16">
        <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ background: '#D1FAE5' }}>
          <svg className="w-10 h-10" style={{ color: '#10B981' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
        <h2 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 32, fontWeight: 700, color: 'var(--primary)', marginBottom: 8 }}>
          Session ended
        </h2>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 40, fontWeight: 700, color: 'var(--primary)', marginBottom: 4 }}>
          €{currentCost.toFixed(2)}
        </div>
        <div style={{ fontSize: 14, color: 'var(--muted-foreground)', marginBottom: 24 }}>
          Final cost · {fmt(elapsed)} · EU-NANO-2026
        </div>
        <button
          onClick={() => onNavigate('my-bookings')}
          className="px-8 py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90"
          style={{ background: 'var(--primary)' }}
        >
          View booking history
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {/* Tool header */}
      <div
        className="rounded-2xl p-6"
        style={{ background: 'var(--primary)' }}
      >
        <div className="flex items-start justify-between">
          <div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', marginBottom: 4, fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase' }}>
              Session active
            </div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 28, fontWeight: 700, color: '#fff' }}>
              Heidelberg MLA 150
            </div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 4 }}>
              NFL · Sessions ends at 11:00
            </div>
          </div>
          <div
            className="px-3 py-1.5 rounded-full flex items-center gap-2"
            style={{ background: 'rgba(16,185,129,0.2)', border: '1px solid rgba(16,185,129,0.4)' }}
          >
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#10B981' }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: '#34D399' }}>LIVE</span>
          </div>
        </div>

        {/* Time progress bar */}
        <div className="mt-5">
          <div className="flex justify-between mb-1.5">
            <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>09:00</span>
            <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>11:00</span>
          </div>
          <div style={{ height: 8, background: 'rgba(255,255,255,0.15)', borderRadius: 4, overflow: 'hidden' }}>
            <div
              style={{
                height: '100%',
                width: `${(elapsed / totalDuration) * 100}%`,
                background: 'var(--accent)',
                borderRadius: 4,
                transition: 'width 1s linear',
              }}
            />
          </div>
        </div>
      </div>

      {/* Equipment state */}
      <div
        className="rounded-xl p-5"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 12 }}>
          Equipment State
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div
            className="p-4 rounded-xl text-center"
            style={{ background: '#D1FAE5', border: '1px solid #A7F3D0' }}
          >
            <div style={{ fontSize: 11, color: '#065F46', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 6 }}>
              Equipment
            </div>
            <div className="flex items-center justify-center gap-1.5">
              <span className="w-2 h-2 rounded-full" style={{ background: '#10B981' }} />
              <span style={{ fontSize: 13, fontWeight: 700, color: '#065F46' }}>Ready</span>
            </div>
          </div>
          <div
            className="p-4 rounded-xl text-center cursor-pointer"
            style={{ background: interlockState === 'connected' ? '#E6EBF5' : '#FEE2E2', border: `1px solid ${interlockState === 'connected' ? '#C0CBE6' : '#FCA5A5'}` }}
            onClick={() => setInterlockState(interlockState === 'connected' ? 'disconnected' : 'connected')}
          >
            <div style={{ fontSize: 11, color: 'var(--muted-foreground)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 6 }}>
              Interlock
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: interlockState === 'connected' ? 'var(--primary)' : '#DC2626' }}>
              {interlockState === 'connected' ? 'CONNECTED' : 'OPEN'}
            </div>
          </div>
          <div
            className="p-4 rounded-xl text-center cursor-pointer"
            style={{ background: powerState === 'on' ? '#D1FAE5' : '#F3F4F6', border: '1px solid var(--border)' }}
            onClick={() => setPowerState(powerState === 'on' ? 'off' : 'on')}
          >
            <div style={{ fontSize: 11, color: 'var(--muted-foreground)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 6 }}>
              Power
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: powerState === 'on' ? '#065F46' : 'var(--muted-foreground)' }}>
              {powerState === 'on' ? 'ON' : 'OFF'}
            </div>
          </div>
        </div>
      </div>

      {/* Session stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Started', value: '09:00' },
          { label: 'Elapsed', value: fmt(elapsed) },
          { label: 'Remaining', value: remaining > 0 ? fmt(remaining) : 'Overtime' },
        ].map((s) => (
          <div
            key={s.label}
            className="p-5 rounded-xl text-center"
            style={{ background: '#fff', border: '1px solid var(--border)' }}
          >
            <div style={{ fontSize: 11, color: 'var(--muted-foreground)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>
              {s.label}
            </div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 26, fontWeight: 700, color: 'var(--primary)' }}>
              {s.value}
            </div>
          </div>
        ))}
      </div>

      {/* Live cost */}
      <div
        className="rounded-xl p-6 text-center"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>
          Current estimated cost
        </div>
        <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 52, fontWeight: 700, color: 'var(--primary)', lineHeight: 1 }}>
          €{currentCost.toFixed(2)}
        </div>
        <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 8 }}>
          EU-NANO-2026 · €95/h · updates every second
        </div>
      </div>

      {/* End session */}
      <button
        onClick={() => setEnded(true)}
        className="w-full py-4 rounded-xl font-semibold text-base transition-all hover:opacity-90"
        style={{ background: '#EF4444', color: '#fff' }}
      >
        End session
      </button>
      <div style={{ fontSize: 12, color: 'var(--muted-foreground)', textAlign: 'center' }}>
        Ending session will lock the equipment interlock and finalise billing.
      </div>
    </div>
  );
}
