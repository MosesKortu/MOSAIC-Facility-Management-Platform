import { useState } from 'react';

interface GrantSelectProps {
  bookingCost: number;
  onSelect: (grant: string, remaining: number) => void;
}

const GRANTS = [
  { id: 'eu-nano', code: 'EU-NANO-2026', name: 'EU Nano-Photonics Excellence', balance: 3240, used: 1760 },
  { id: 'icfo-int', code: 'ICFO-INTERNAL', name: 'ICFO Internal Discretionary', balance: 90, used: 410 },
  { id: 'micinn', code: 'ES-MICINN-2026', name: 'Spanish MICINN Research Grant', balance: 8120, used: 3440 },
];

export default function GrantSelect({ bookingCost, onSelect }: GrantSelectProps) {
  const [selected, setSelected] = useState('eu-nano');

  const selectedGrant = GRANTS.find((g) => g.id === selected);
  const canAfford = (g: typeof GRANTS[0]) => g.balance >= bookingCost;

  return (
    <div className="max-w-lg mx-auto space-y-5">
      <div>
        <h1 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 26, fontWeight: 700, color: 'var(--primary)', marginBottom: 4 }}>
          Choose Funding
        </h1>
        <div style={{ fontSize: 14, color: 'var(--muted-foreground)' }}>
          Select a grant for this session. Total to charge:{' '}
          <strong style={{ color: 'var(--primary)', fontFamily: 'JetBrains Mono, monospace' }}>€{bookingCost.toFixed(0)}</strong>
        </div>
      </div>

      <div className="space-y-3">
        {GRANTS.map((grant) => {
          const affordable = canAfford(grant);
          const isSelected = selected === grant.id;
          const remaining = grant.balance - bookingCost;
          const pct = Math.round((grant.used / (grant.balance + grant.used)) * 100);

          return (
            <div
              key={grant.id}
              onClick={() => affordable && setSelected(grant.id)}
              className="rounded-xl p-5 transition-all"
              style={{
                border: `2px solid ${isSelected ? 'var(--primary)' : affordable ? 'var(--border)' : '#E5E7EB'}`,
                background: isSelected ? 'var(--card)' : '#fff',
                cursor: affordable ? 'pointer' : 'not-allowed',
                opacity: affordable ? 1 : 0.65,
              }}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  <input
                    type="radio"
                    checked={isSelected}
                    onChange={() => affordable && setSelected(grant.id)}
                    disabled={!affordable}
                    style={{ accentColor: 'var(--primary)' }}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-0.5">
                    <span style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 17, fontWeight: 700, color: affordable ? 'var(--primary)' : 'var(--muted-foreground)' }}>
                      {grant.code}
                    </span>
                    {!affordable && (
                      <span
                        className="px-2 py-0.5 rounded text-xs font-semibold"
                        style={{ background: '#FEE2E2', color: '#DC2626' }}
                      >
                        ✕ Insufficient funds
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginBottom: 12 }}>{grant.name}</div>

                  {/* Balance bar */}
                  <div style={{ height: 6, background: 'var(--muted)', borderRadius: 3, overflow: 'hidden', marginBottom: 6 }}>
                    <div style={{ width: `${pct}%`, height: '100%', background: affordable ? 'var(--primary)' : '#9CA3AF', borderRadius: 3 }} />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginBottom: 2 }}>Available</div>
                      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 16, fontWeight: 700, color: affordable ? 'var(--primary)' : 'var(--muted-foreground)' }}>
                        €{grant.balance.toLocaleString()}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginBottom: 2 }}>This booking</div>
                      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 16, fontWeight: 700, color: '#EF4444' }}>
                        −€{bookingCost.toFixed(0)}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginBottom: 2 }}>Remaining</div>
                      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 16, fontWeight: 700, color: affordable ? '#10B981' : '#EF4444' }}>
                        {affordable ? `€${remaining.toLocaleString()}` : 'Insufficient'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <button
        onClick={() => {
          if (selectedGrant) {
            onSelect(selectedGrant.code, selectedGrant.balance - bookingCost);
          }
        }}
        disabled={!selectedGrant || !canAfford(selectedGrant)}
        className="w-full py-4 rounded-xl font-semibold text-white text-base transition-all hover:opacity-90 disabled:opacity-40"
        style={{ background: 'var(--primary)' }}
      >
        Review booking →
      </button>
    </div>
  );
}
