import { useState } from 'react';
import type { Page } from '../components/Shell';

interface MyBookingsProps {
  onNavigate: (page: Page) => void;
  onStartSession: () => void;
}

const BOOKINGS = {
  upcoming: [
    { id: 'b1', date: '22 SEP', time: '09:00–11:00', tool: 'Heidelberg MLA 150', facility: 'NFL', cost: 190, grant: 'EU-NANO-2026', status: 'confirmed', ref: 'MOSAIC-28417' },
    { id: 'b2', date: '22 SEP', time: '14:00–15:00', tool: 'Oxford Instruments RIE', facility: 'NFL', cost: 140, grant: 'EU-NANO-2026', status: 'confirmed', ref: 'MOSAIC-28391' },
    { id: 'b3', date: '24 SEP', time: '10:00–13:00', tool: 'JEOL SEM 7000F', facility: 'NCL', cost: 216, grant: 'ES-MICINN-2026', status: 'confirmed', ref: 'MOSAIC-28503' },
  ],
  active: [
  ],
  completed: [
    { id: 'b4', date: '20 SEP', time: '10:00–12:00', tool: 'Oxford Instruments RIE', facility: 'NFL', cost: 280, grant: 'EU-NANO-2026', status: 'completed', ref: 'MOSAIC-28201' },
    { id: 'b5', date: '18 SEP', time: '09:00–10:00', tool: 'Heidelberg MLA 150', facility: 'NFL', cost: 95, grant: 'EU-NANO-2026', status: 'completed', ref: 'MOSAIC-28104' },
    { id: 'b6', date: '15 SEP', time: '14:00–17:00', tool: 'ALD Beneq TFS-200', facility: 'NFL', cost: 174, grant: 'ES-MICINN-2026', status: 'completed', ref: 'MOSAIC-27983' },
  ],
};

type TabKey = 'upcoming' | 'active' | 'completed';

export default function MyBookings({ onNavigate, onStartSession }: MyBookingsProps) {
  const [tab, setTab] = useState<TabKey>('upcoming');

  const list = BOOKINGS[tab];

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Tabs */}
      <div
        className="flex gap-1 p-1 rounded-xl"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        {[
          { id: 'upcoming', label: `Upcoming (${BOOKINGS.upcoming.length})` },
          { id: 'active', label: `Active (${BOOKINGS.active.length})` },
          { id: 'completed', label: `Completed (${BOOKINGS.completed.length})` },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id as TabKey)}
            className="flex-1 py-2 rounded-lg text-sm font-medium transition-all"
            style={{
              background: tab === t.id ? 'var(--primary)' : 'transparent',
              color: tab === t.id ? '#fff' : 'var(--muted-foreground)',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Booking list */}
      <div className="space-y-3">
        {list.length === 0 && (
          <div className="text-center py-16" style={{ color: 'var(--muted-foreground)' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>📋</div>
            <div style={{ fontSize: 15, fontWeight: 500 }}>No {tab} bookings</div>
            {tab === 'active' && (
              <div style={{ fontSize: 13, marginTop: 8 }}>
                Active sessions appear here once you unlock the equipment interlock.
              </div>
            )}
          </div>
        )}

        {list.map((booking) => (
          <div
            key={booking.id}
            className="rounded-xl overflow-hidden"
            style={{ background: '#fff', border: '1px solid var(--border)' }}
          >
            <div className="flex items-stretch">
              {/* Date column */}
              <div
                className="flex flex-col items-center justify-center px-5 shrink-0"
                style={{ background: 'var(--primary)', minWidth: 72 }}
              >
                <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.6)', letterSpacing: '0.1em', textTransform: 'uppercase', lineHeight: 1 }}>
                  {booking.date.split(' ')[1]}
                </div>
                <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 28, fontWeight: 700, color: '#fff', lineHeight: 1.1 }}>
                  {booking.date.split(' ')[0]}
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 17, fontWeight: 700, color: 'var(--primary)', lineHeight: 1.2 }}>
                      {booking.tool}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 2 }}>
                      {booking.facility} · {booking.time}
                    </div>
                  </div>
                  <span
                    className="px-2 py-0.5 rounded-full text-xs font-semibold shrink-0"
                    style={{
                      background: booking.status === 'confirmed' ? '#E6EBF5' : booking.status === 'completed' ? '#F3F4F6' : '#D1FAE5',
                      color: booking.status === 'confirmed' ? 'var(--primary)' : booking.status === 'completed' ? 'var(--muted-foreground)' : '#065F46',
                      textTransform: 'uppercase',
                      letterSpacing: '0.06em',
                    }}
                  >
                    {booking.status}
                  </span>
                </div>

                <div className="flex items-center gap-3 mt-3">
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 15, fontWeight: 700, color: 'var(--primary)' }}>
                    €{booking.cost}
                  </span>
                  <span style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>{booking.grant}</span>
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--muted-foreground)', marginLeft: 'auto' }}>
                    {booking.ref}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col gap-1 p-3 justify-center shrink-0" style={{ borderLeft: '1px solid var(--border)' }}>
                {booking.status === 'confirmed' && (
                  <>
                    <button
                      onClick={onStartSession}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white transition-all hover:opacity-90"
                      style={{ background: 'var(--primary)' }}
                    >
                      Start
                    </button>
                    <button
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                      style={{ border: '1px solid #EF4444', color: '#EF4444' }}
                    >
                      Cancel
                    </button>
                  </>
                )}
                {booking.status === 'completed' && (
                  <button
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                    style={{ border: '1px solid var(--border)', color: 'var(--muted-foreground)' }}
                  >
                    View
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {tab === 'upcoming' && (
        <button
          onClick={() => onNavigate('equipment')}
          className="w-full py-3 rounded-xl text-sm font-semibold transition-all hover:opacity-90"
          style={{ border: '2px dashed var(--border)', color: 'var(--muted-foreground)', background: '#fff' }}
        >
          + Book new session
        </button>
      )}
    </div>
  );
}
