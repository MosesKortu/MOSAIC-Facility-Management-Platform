import { useState } from 'react';
import type { Tool } from './Equipment';

interface CalendarPageProps {
  tool: Tool;
  onSelectSlot: (date: string, start: string, end: string) => void;
}

const DAYS = [
  { label: 'Mon', date: '22', full: '22 Sep' },
  { label: 'Tue', date: '23', full: '23 Sep' },
  { label: 'Wed', date: '24', full: '24 Sep' },
  { label: 'Thu', date: '25', full: '25 Sep' },
  { label: 'Fri', date: '26', full: '26 Sep' },
];

const HOURS = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];

// Which slots are booked per day index (0=Mon)
const BOOKED: Record<number, string[]> = {
  0: ['11:00', '12:00'],
  1: ['09:00', '10:00', '14:00'],
  2: [],
  3: ['16:00', '17:00'],
  4: ['08:00'],
};

const BUFFER = ['08:00']; // pre-session buffer always blocked

export default function CalendarPage({ tool, onSelectSlot }: CalendarPageProps) {
  const [selectedDay, setSelectedDay] = useState(0);
  const [selStart, setSelStart] = useState<string | null>(null);
  const [selEnd, setSelEnd] = useState<string | null>(null);

  const booked = BOOKED[selectedDay] ?? [];

  const isBooked = (h: string) => booked.includes(h) || BUFFER.includes(h);
  const isSelected = (h: string) => {
    if (!selStart) return false;
    const hi = HOURS.indexOf(h);
    const si = HOURS.indexOf(selStart);
    const ei = selEnd ? HOURS.indexOf(selEnd) : si;
    return hi >= si && hi <= ei;
  };

  const handleSlotClick = (h: string) => {
    if (isBooked(h)) return;
    if (!selStart || selEnd) {
      setSelStart(h);
      setSelEnd(null);
    } else {
      const si = HOURS.indexOf(selStart);
      const hi = HOURS.indexOf(h);
      if (hi < si) {
        setSelStart(h);
        setSelEnd(null);
      } else {
        setSelEnd(h);
      }
    }
  };

  const duration = selStart && selEnd
    ? HOURS.indexOf(selEnd) - HOURS.indexOf(selStart) + 1
    : selStart
    ? 1
    : 0;

  const endLabel = selEnd
    ? HOURS[HOURS.indexOf(selEnd) + 1] ?? '18:00'
    : selStart
    ? HOURS[HOURS.indexOf(selStart) + 1] ?? '18:00'
    : null;

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Header */}
      <div
        className="rounded-xl p-5"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        <div className="flex items-center justify-between">
          <div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 20, fontWeight: 700, color: 'var(--primary)' }}>
              {tool.name}
            </div>
            <div style={{ fontSize: 13, color: 'var(--muted-foreground)', marginTop: 2 }}>September 2026 · Select your time slot</div>
          </div>
          <div
            className="px-3 py-1 rounded text-xs font-semibold"
            style={{ background: 'var(--primary)', color: 'var(--accent)', fontFamily: 'Barlow Condensed, sans-serif', letterSpacing: '0.08em' }}
          >
            {tool.facility}
          </div>
        </div>
      </div>

      {/* Day selector */}
      <div className="grid grid-cols-5 gap-2">
        {DAYS.map((d, i) => (
          <button
            key={i}
            onClick={() => { setSelectedDay(i); setSelStart(null); setSelEnd(null); }}
            className="py-3 rounded-xl text-center transition-all"
            style={{
              background: selectedDay === i ? 'var(--primary)' : '#fff',
              color: selectedDay === i ? '#fff' : 'var(--foreground)',
              border: `1px solid ${selectedDay === i ? 'var(--primary)' : 'var(--border)'}`,
            }}
          >
            <div style={{ fontSize: 11, color: selectedDay === i ? 'rgba(255,255,255,0.7)' : 'var(--muted-foreground)', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
              {d.label}
            </div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 22, fontWeight: 700, lineHeight: 1.2, marginTop: 2 }}>
              {d.date}
            </div>
          </button>
        ))}
      </div>

      {/* Time grid */}
      <div
        className="rounded-xl overflow-hidden"
        style={{ background: '#fff', border: '1px solid var(--border)' }}
      >
        <div className="px-5 py-3" style={{ borderBottom: '1px solid var(--border)', background: 'var(--card)' }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--foreground)' }}>
            {DAYS[selectedDay].full} · Click to select a time range
          </div>
        </div>
        <div className="p-4 space-y-2">
          {HOURS.map((h) => {
            const booked = isBooked(h);
            const selected = isSelected(h);
            const isStart = h === selStart;
            return (
              <button
                key={h}
                onClick={() => handleSlotClick(h)}
                disabled={booked}
                className="w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all text-left"
                style={{
                  background: selected
                    ? 'var(--primary)'
                    : booked
                    ? '#F3F4F6'
                    : 'var(--card)',
                  border: isStart ? '2px solid var(--accent)' : `1px solid ${selected ? 'var(--primary)' : booked ? '#E5E7EB' : 'var(--border)'}`,
                  cursor: booked ? 'not-allowed' : 'pointer',
                  opacity: booked ? 0.6 : 1,
                }}
              >
                <span
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: 13,
                    fontWeight: 600,
                    color: selected ? 'rgba(255,255,255,0.8)' : 'var(--muted-foreground)',
                    width: 48,
                    shrink: 0,
                  }}
                >
                  {h}
                </span>
                <div
                  className="flex-1 flex items-center"
                  style={{
                    height: 28,
                    background: selected ? 'rgba(255,255,255,0.15)' : booked ? '#E5E7EB' : 'rgba(3,47,155,0.06)',
                    borderRadius: 6,
                    paddingLeft: 10,
                  }}
                >
                  <span style={{ fontSize: 12, fontWeight: 500, color: selected ? '#fff' : booked ? '#9CA3AF' : 'var(--primary)' }}>
                    {booked ? 'BOOKED' : selected ? (isStart ? 'START' : '▸ SELECTED') : 'AVAILABLE'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selection summary + CTA */}
      {selStart && (
        <div
          className="rounded-xl p-5 flex items-center gap-4"
          style={{ background: 'var(--primary)', border: '1px solid var(--primary)' }}
        >
          <div className="flex-1">
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)', marginBottom: 2 }}>Selected slot</div>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 22, fontWeight: 700, color: '#fff' }}>
              {DAYS[selectedDay].full} · {selStart}–{endLabel}
            </div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)', marginTop: 2 }}>
              {duration} hour{duration !== 1 ? 's' : ''} selected
            </div>
          </div>
          <button
            onClick={() => {
              if (selStart && endLabel) {
                onSelectSlot(`${DAYS[selectedDay].full} 2026`, selStart, endLabel);
              }
            }}
            className="px-6 py-3 rounded-xl font-semibold transition-all hover:opacity-90 shrink-0"
            style={{ background: 'var(--accent)', color: 'var(--primary)', fontSize: 15 }}
          >
            Continue →
          </button>
        </div>
      )}

      {/* Legend */}
      <div className="flex items-center gap-5" style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>
        <div className="flex items-center gap-2">
          <div style={{ width: 16, height: 8, background: 'rgba(3,47,155,0.1)', borderRadius: 3 }} />
          Available
        </div>
        <div className="flex items-center gap-2">
          <div style={{ width: 16, height: 8, background: 'var(--primary)', borderRadius: 3 }} />
          Your selection
        </div>
        <div className="flex items-center gap-2">
          <div style={{ width: 16, height: 8, background: '#E5E7EB', borderRadius: 3 }} />
          Booked
        </div>
      </div>
    </div>
  );
}
