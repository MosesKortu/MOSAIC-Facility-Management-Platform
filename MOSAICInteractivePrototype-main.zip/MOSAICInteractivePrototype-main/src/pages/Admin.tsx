import { useState } from 'react';

type UserRole = 'standard' | 'superuser' | 'admin';

interface Person {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  group: string;
  certifications: string[];
  activeGrants: number;
  lastSeen: string;
  status: 'active' | 'pending' | 'suspended';
}

const PEOPLE: Person[] = [
  {
    id: 'u1',
    name: 'Dr. Alex Rivera',
    email: 'a.rivera@icfo.eu',
    role: 'standard',
    group: 'Quantum Nano-Photonics',
    certifications: ['HDB-MLA150', 'RIE-OXFORD'],
    activeGrants: 2,
    lastSeen: '2026-09-20',
    status: 'active',
  },
  {
    id: 'u2',
    name: 'Dr. Maria Llopis',
    email: 'm.llopis@icfo.eu',
    role: 'superuser',
    group: 'NFL Staff',
    certifications: ['HDB-MLA150', 'RIE-OXFORD', 'EBL-CRESTEC', 'FIB-ORION', 'ALD-BENEQ'],
    activeGrants: 1,
    lastSeen: '2026-09-20',
    status: 'active',
  },
  {
    id: 'u3',
    name: 'Dr. Pau García',
    email: 'p.garcia@icfo.eu',
    role: 'standard',
    group: 'Ultrafast Laser Science',
    certifications: ['EBL-CRESTEC', 'HDB-MLA150'],
    activeGrants: 3,
    lastSeen: '2026-09-19',
    status: 'active',
  },
  {
    id: 'u4',
    name: 'Antoine Chen',
    email: 'a.chen@partner-uni.de',
    role: 'standard',
    group: 'External — TU Berlin',
    certifications: ['HDB-MLA150'],
    activeGrants: 1,
    lastSeen: '2026-09-18',
    status: 'active',
  },
  {
    id: 'u5',
    name: 'Dr. Sonia Patel',
    email: 's.patel@icfo.eu',
    role: 'standard',
    group: 'SLN Microscopy',
    certifications: [],
    activeGrants: 1,
    lastSeen: '2026-09-17',
    status: 'pending',
  },
  {
    id: 'u6',
    name: 'Björn Müller',
    email: 'b.mueller@mpq.mpg.de',
    role: 'standard',
    group: 'External — MPQ Munich',
    certifications: ['RIE-OXFORD', 'ALD-BENEQ'],
    activeGrants: 0,
    lastSeen: '2026-09-10',
    status: 'active',
  },
  {
    id: 'u7',
    name: 'Dr. Ferran Marsà',
    email: 'f.marsa@icfo.eu',
    role: 'admin',
    group: 'NFL Management',
    certifications: ['HDB-MLA150', 'RIE-OXFORD', 'EBL-CRESTEC', 'FIB-ORION', 'ALD-BENEQ', 'SPUTTER'],
    activeGrants: 0,
    lastSeen: '2026-09-20',
    status: 'active',
  },
  {
    id: 'u8',
    name: 'Prof. Marta Torres',
    email: 'm.torres@icfo.eu',
    role: 'standard',
    group: 'Nanostructured Photovoltaics',
    certifications: ['RIE-OXFORD', 'ALD-BENEQ', 'EBL-CRESTEC'],
    activeGrants: 4,
    lastSeen: '2026-09-20',
    status: 'active',
  },
];

const ROLE_CONFIG: Record<UserRole, { label: string; color: string; bg: string }> = {
  standard: { label: 'Standard User', color: '#333', bg: '#F3F4F6' },
  superuser: { label: 'Super User', color: '#92400E', bg: '#FEF3C7' },
  admin: { label: 'Super Admin', color: '#032F9B', bg: '#E6EBF5' },
};

const STATUS_CONFIG = {
  active: { label: 'Active', color: '#10B981', bg: '#D1FAE5' },
  pending: { label: 'Pending', color: '#F59E0B', bg: '#FEF3C7' },
  suspended: { label: 'Suspended', color: '#EF4444', bg: '#FEE2E2' },
};

export default function Admin() {
  const [people, setPeople] = useState(PEOPLE);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  const [showInvite, setShowInvite] = useState(false);
  const [inviteForm, setInviteForm] = useState({ name: '', email: '', role: 'standard' as UserRole, group: '' });

  const filtered = people.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.email.toLowerCase().includes(search.toLowerCase()) || p.group.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === 'all' || p.role === roleFilter;
    return matchSearch && matchRole;
  });

  const promoteRole = (person: Person, newRole: UserRole) => {
    setPeople((prev) => prev.map((p) => (p.id === person.id ? { ...p, role: newRole } : p)));
    setSelectedPerson((prev) => (prev ? { ...prev, role: newRole } : null));
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Users', value: people.length, color: 'var(--primary)' },
          { label: 'Active', value: people.filter((p) => p.status === 'active').length, color: '#10B981' },
          { label: 'Pending Approval', value: people.filter((p) => p.status === 'pending').length, color: '#F59E0B' },
          { label: 'Super Users', value: people.filter((p) => p.role !== 'standard').length, color: '#8B5CF6' },
        ].map((s) => (
          <div key={s.label} className="p-4 rounded-xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 32, fontWeight: 700, color: s.color }}>
              {s.value}
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted-foreground)', fontWeight: 500 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-48">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--muted-foreground)' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search users…"
            className="w-full pl-9 pr-4 py-2 rounded-lg text-sm outline-none"
            style={{ border: '1px solid var(--border)', background: 'var(--card)' }}
          />
        </div>
        <div className="flex gap-2">
          {(['all', 'standard', 'superuser', 'admin'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRoleFilter(r)}
              className="px-3 py-2 rounded-lg text-sm font-medium transition-all capitalize"
              style={{
                background: roleFilter === r ? 'var(--primary)' : 'var(--card)',
                color: roleFilter === r ? '#fff' : 'var(--foreground)',
                border: `1px solid ${roleFilter === r ? 'var(--primary)' : 'var(--border)'}`,
              }}
            >
              {r === 'all' ? 'All Roles' : ROLE_CONFIG[r].label}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowInvite(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90"
          style={{ background: 'var(--primary)' }}
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
          Invite User
        </button>
      </div>

      {/* People table */}
      <div className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
        <table className="w-full" style={{ background: '#fff' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)', background: 'var(--card)' }}>
              {['User', 'Role', 'Group', 'Certifications', 'Grants', 'Status', ''].map((h) => (
                <th key={h} className="px-5 py-3 text-left" style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((person, i) => {
              const rc = ROLE_CONFIG[person.role];
              const sc = STATUS_CONFIG[person.status];
              return (
                <tr
                  key={person.id}
                  style={{ borderBottom: i < filtered.length - 1 ? '1px solid var(--border)' : 'none', cursor: 'pointer' }}
                  onClick={() => setSelectedPerson(person)}
                  onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--card)')}
                  onMouseLeave={(e) => (e.currentTarget.style.background = '#fff')}
                >
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                        style={{ background: 'var(--primary)', color: 'var(--accent)' }}
                      >
                        {person.name.split(' ').slice(-2).map((n) => n[0]).join('').toUpperCase().slice(0, 2)}
                      </div>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--foreground)' }}>{person.name}</div>
                        <div style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>{person.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <span className="px-2 py-0.5 rounded text-xs font-semibold" style={{ background: rc.bg, color: rc.color }}>
                      {rc.label}
                    </span>
                  </td>
                  <td className="px-5 py-4" style={{ fontSize: 13, color: 'var(--muted-foreground)', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {person.group}
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-1 flex-wrap">
                      {person.certifications.length === 0 ? (
                        <span style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>None</span>
                      ) : (
                        <>
                          {person.certifications.slice(0, 2).map((c) => (
                            <span key={c} className="px-1.5 py-0.5 rounded text-xs" style={{ background: '#E6EBF5', color: 'var(--primary)', fontFamily: 'JetBrains Mono, monospace' }}>
                              {c}
                            </span>
                          ))}
                          {person.certifications.length > 2 && (
                            <span style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>+{person.certifications.length - 2}</span>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, color: 'var(--foreground)' }}>
                      {person.activeGrants}
                    </span>
                  </td>
                  <td className="px-5 py-4">
                    <span className="px-2 py-0.5 rounded-full text-xs font-semibold" style={{ background: sc.bg, color: sc.color }}>
                      {sc.label}
                    </span>
                  </td>
                  <td className="px-5 py-4">
                    <button
                      onClick={(e) => { e.stopPropagation(); setSelectedPerson(person); }}
                      style={{ fontSize: 12, color: 'var(--primary)', fontWeight: 600 }}
                    >
                      Manage →
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Person detail modal */}
      {selectedPerson && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{ background: 'rgba(0,0,0,0.4)' }}
          onClick={() => setSelectedPerson(null)}
        >
          <div
            className="w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl"
            style={{ background: '#fff' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6" style={{ background: 'var(--primary)' }}>
              <div className="flex items-center gap-4">
                <div
                  className="w-14 h-14 rounded-full flex items-center justify-center text-lg font-bold"
                  style={{ background: 'var(--accent)', color: 'var(--primary)' }}
                >
                  {selectedPerson.name.split(' ').slice(-2).map((n) => n[0]).join('').toUpperCase().slice(0, 2)}
                </div>
                <div>
                  <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 22, fontWeight: 700, color: '#fff' }}>
                    {selectedPerson.name}
                  </div>
                  <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: 13 }}>{selectedPerson.email}</div>
                </div>
                <button onClick={() => setSelectedPerson(null)} className="ml-auto" style={{ color: 'rgba(255,255,255,0.6)' }}>
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                  </svg>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-5">
              {/* Role management */}
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 8 }}>
                  Role Assignment
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(['standard', 'superuser', 'admin'] as UserRole[]).map((r) => {
                    const rc = ROLE_CONFIG[r];
                    const active = selectedPerson.role === r;
                    return (
                      <button
                        key={r}
                        onClick={() => promoteRole(selectedPerson, r)}
                        className="py-2 px-3 rounded-lg text-sm font-semibold transition-all"
                        style={{
                          background: active ? 'var(--primary)' : 'var(--card)',
                          color: active ? '#fff' : rc.color,
                          border: `1px solid ${active ? 'var(--primary)' : 'var(--border)'}`,
                        }}
                      >
                        {rc.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Certifications */}
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 8 }}>
                  Certifications ({selectedPerson.certifications.length})
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedPerson.certifications.length === 0 ? (
                    <span style={{ fontSize: 13, color: 'var(--muted-foreground)' }}>No certifications yet</span>
                  ) : (
                    selectedPerson.certifications.map((c) => (
                      <span key={c} className="px-3 py-1 rounded-full text-xs font-semibold" style={{ background: '#D1FAE5', color: '#065F46', fontFamily: 'JetBrains Mono, monospace' }}>
                        ✓ {c}
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: 'Active Grants', value: selectedPerson.activeGrants },
                  { label: 'Certifications', value: selectedPerson.certifications.length },
                  { label: 'Last Active', value: selectedPerson.lastSeen.slice(5) },
                ].map((s) => (
                  <div key={s.label} className="p-3 rounded-lg text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                    <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 22, fontWeight: 700, color: 'var(--primary)' }}>{s.value}</div>
                    <div style={{ fontSize: 11, color: 'var(--muted-foreground)' }}>{s.label}</div>
                  </div>
                ))}
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-2" style={{ borderTop: '1px solid var(--border)' }}>
                <button
                  onClick={() => { setPeople((prev) => prev.map((p) => p.id === selectedPerson.id ? { ...p, status: p.status === 'suspended' ? 'active' : 'suspended' } : p)); setSelectedPerson(null); }}
                  className="flex-1 py-2 rounded-lg text-sm font-semibold transition-all"
                  style={{ border: '1px solid var(--border)', color: '#EF4444' }}
                >
                  {selectedPerson.status === 'suspended' ? 'Reinstate' : 'Suspend'}
                </button>
                <button
                  onClick={() => setSelectedPerson(null)}
                  className="flex-1 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90"
                  style={{ background: 'var(--primary)' }}
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Invite modal */}
      {showInvite && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{ background: 'rgba(0,0,0,0.4)' }}
          onClick={() => setShowInvite(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl p-8 shadow-2xl"
            style={{ background: '#fff' }}
            onClick={(e) => e.stopPropagation()}
          >
            <h2 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 24, fontWeight: 700, color: 'var(--primary)', marginBottom: 20 }}>
              Invite New User
            </h2>
            <div className="space-y-4">
              {['name', 'email', 'group'].map((field) => (
                <div key={field}>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 4 }}>
                    {field === 'name' ? 'Full Name' : field === 'email' ? 'Email Address' : 'Research Group'}
                  </label>
                  <input
                    value={inviteForm[field as keyof typeof inviteForm]}
                    onChange={(e) => setInviteForm({ ...inviteForm, [field]: e.target.value })}
                    placeholder={field === 'name' ? 'Dr. Jane Smith' : field === 'email' ? 'j.smith@institution.eu' : 'Quantum Photonics Group'}
                    className="w-full px-4 py-2.5 rounded-lg text-sm outline-none"
                    style={{ border: '1px solid var(--border)', background: 'var(--card)' }}
                  />
                </div>
              ))}
              <div>
                <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 4 }}>
                  Initial Role
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['standard', 'superuser', 'admin'] as UserRole[]).map((r) => (
                    <button
                      key={r}
                      onClick={() => setInviteForm({ ...inviteForm, role: r })}
                      className="py-2 rounded-lg text-sm font-semibold transition-all"
                      style={{
                        background: inviteForm.role === r ? 'var(--primary)' : 'var(--card)',
                        color: inviteForm.role === r ? '#fff' : 'var(--muted-foreground)',
                        border: `1px solid ${inviteForm.role === r ? 'var(--primary)' : 'var(--border)'}`,
                        fontFamily: 'Barlow Condensed, sans-serif',
                        fontSize: 13,
                        letterSpacing: '0.04em',
                      }}
                    >
                      {ROLE_CONFIG[r].label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowInvite(false)} className="flex-1 py-2 rounded-lg text-sm" style={{ border: '1px solid var(--border)', color: 'var(--muted-foreground)' }}>
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (inviteForm.name && inviteForm.email) {
                      setPeople((prev) => [...prev, {
                        id: `u${Date.now()}`,
                        name: inviteForm.name,
                        email: inviteForm.email,
                        role: inviteForm.role,
                        group: inviteForm.group || 'Unassigned',
                        certifications: [],
                        activeGrants: 0,
                        lastSeen: 'Never',
                        status: 'pending',
                      }]);
                      setShowInvite(false);
                      setInviteForm({ name: '', email: '', role: 'standard', group: '' });
                    }
                  }}
                  className="flex-1 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90"
                  style={{ background: 'var(--primary)' }}
                >
                  Send Invitation
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
