import type { Tool } from './Equipment';

interface BookingReviewProps {
  tool: Tool;
  date: string;
  start: string;
  end: string;
  support: string;
  supportRate: number;
  grant: string;
  grantRemaining: number;
  totalCost: number;
  onConfirm: () => void;
  onBack: () => void;
}

const SUPPORT_LABELS: Record<string, string> = {
  autonomous: 'Autonomous',
  technician: 'Technician Support',
  supervisor: 'Supervisor Support',
};

export default function BookingReview({
  tool, date, start, end, support, supportRate, grant, grantRemaining, totalCost, onConfirm, onBack,
}: BookingReviewProps) {
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  const hours = Math.max(1, (eh * 60 + em - (sh * 60 + sm)) / 60);
  const machineCost = tool.rate * hours;
  const supportCost = supportRate * hours;

  return (
    <div className="max-w-lg mx-auto space-y-5">
      <div>
        <h1 style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 26, fontWeight: 700, color: 'var(--primary)', marginBottom: 4 }}>
          Review your booking
        </h1>
        <div style={{ fontSize: 14, color: 'var(--muted-foreground)' }}>
          Check the details below before confirming.
        </div>
      </div>

      {/* Summary card */}
      <div
        className="rounded-xl overflow-hidden"
        style={{ border: '1px solid var(--border)' }}
      >
        {/* Tool header */}
        <div className="p-5" style={{ background: 'var(--primary)' }}>
          <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 22, fontWeight: 700, color: '#fff', marginBottom: 2 }}>
            {tool.name}
          </div>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>{tool.facility} · {tool.category}</div>
        </div>

        {/* Details */}
        <div className="p-5 space-y-4" style={{ background: '#fff' }}>
          {[
            { label: 'When', value: `${date}\n${start}–${end}` },
            { label: 'Duration', value: `${hours} hours` },
            { label: 'Support', value: SUPPORT_LABELS[support] },
            { label: 'Funding', value: grant },
          ].map((row) => (
            <div key={row.label} className="flex items-start gap-4" style={{ paddingBottom: 12, borderBottom: '1px solid var(--border)' }}>
              <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', width: 72, shrink: 0, paddingTop: 2 }}>
                {row.label}
              </span>
              <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--foreground)', whiteSpace: 'pre-line' }}>
                {row.value}
              </span>
            </div>
          ))}

          {/* Cost */}
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted-foreground)', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 10 }}>
              Cost
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span style={{ fontSize: 14, color: 'var(--muted-foreground)' }}>Equipment ({hours}h × €{tool.rate}/h)</span>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14 }}>€{machineCost.toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span style={{ fontSize: 14, color: 'var(--muted-foreground)' }}>Support</span>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14 }}>€{supportCost.toFixed(0)}</span>
              </div>
              <div className="flex justify-between pt-2" style={{ borderTop: '2px solid var(--primary)' }}>
                <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--primary)' }}>Total</span>
                <span style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 26, fontWeight: 700, color: 'var(--primary)' }}>
                  €{totalCost.toFixed(0)}
                </span>
              </div>
            </div>
          </div>

          {/* After booking */}
          <div
            className="p-3 rounded-xl"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginBottom: 2 }}>Grant remaining after this booking</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 18, fontWeight: 700, color: '#10B981' }}>
              €{grantRemaining.toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* CTAs */}
      <button
        onClick={onConfirm}
        className="w-full py-4 rounded-xl font-semibold text-white text-base transition-all hover:opacity-90"
        style={{ background: 'var(--primary)' }}
      >
        Confirm booking
      </button>
      <button
        onClick={onBack}
        className="w-full py-2 text-sm text-center"
        style={{ color: 'var(--muted-foreground)' }}
      >
        ← Back
      </button>
    </div>
  );
}
