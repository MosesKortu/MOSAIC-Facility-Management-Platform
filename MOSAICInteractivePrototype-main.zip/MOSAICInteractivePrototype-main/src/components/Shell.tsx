import { useState } from 'react';

export type Page =
  | 'home'
  | 'equipment'
  | 'equipment-detail'
  | 'calendar'
  | 'booking-config'
  | 'grant-select'
  | 'booking-review'
  | 'booking-confirm'
  | 'training'
  | 'my-bookings'
  | 'active-session'
  | 'grants'
  | 'admin';

export type Role = 'standard' | 'superuser' | 'admin';

interface NavItem {
  id: Page;
  label: string;
  roles: Role[];
  icon: React.ReactNode;
  dividerBefore?: boolean;
}

const NAV: NavItem[] = [
  {
    id: 'home',
    label: 'Home',
    roles: ['standard', 'superuser', 'admin'],
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
        <polyline points="9 22 9 12 15 12 15 22"/>
      </svg>
    ),
  },
  {
    id: 'equipment',
    label: 'Equipment',
    roles: ['standard', 'superuser', 'admin'],
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="2" y="7" width="20" height="14" rx="2"/>
        <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
      </svg>
    ),
  },
  {
    id: 'calendar',
    label: 'Calendar',
    roles: ['standard', 'superuser', 'admin'],
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="3" y="4" width="18" height="18" rx="2"/>
        <line x1="16" y1="2" x2="16" y2="6"/>
        <line x1="8" y1="2" x2="8" y2="6"/>
        <line x1="3" y1="10" x2="21" y2="10"/>
      </svg>
    ),
  },
  {
    id: 'training',
    label: 'Training',
    roles: ['standard', 'superuser', 'admin'],
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/>
        <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
      </svg>
    ),
  },
  {
    id: 'my-bookings',
    label: 'My Bookings',
    roles: ['standard', 'superuser', 'admin'],
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
        <line x1="16" y1="13" x2="8" y2="13"/>
        <line x1="16" y1="17" x2="8" y2="17"/>
        <polyline points="10 9 9 9 8 9"/>
      </svg>
    ),
  },
  {
    id: 'grants',
    label: 'Grants',
    roles: ['standard', 'superuser', 'admin'],
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <line x1="12" y1="1" x2="12" y2="23"/>
        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
      </svg>
    ),
  },
  {
    id: 'admin',
    label: 'Admin',
    roles: ['superuser', 'admin'],
    dividerBefore: true,
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
        <circle cx="9" cy="7" r="4"/>
        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
      </svg>
    ),
  },
];

const TOP_LEVEL_PAGES: Page[] = ['home', 'equipment', 'calendar', 'training', 'my-bookings', 'grants', 'admin'];

const PAGE_LABELS: Partial<Record<Page, string>> = {
  home: 'Home',
  equipment: 'Equipment',
  'equipment-detail': 'Equipment Detail',
  calendar: 'Calendar',
  'booking-config': 'Book Equipment',
  'grant-select': 'Choose Funding',
  'booking-review': 'Review Booking',
  'booking-confirm': 'Booking Confirmed',
  training: 'Training',
  'my-bookings': 'My Bookings',
  'active-session': 'Active Session',
  grants: 'Grants',
  admin: 'People',
};

const ROLE_LABELS: Record<Role, string> = {
  standard: 'Researcher',
  superuser: 'Super User',
  admin: 'Super Admin',
};

const USER_NAMES: Record<Role, string> = {
  standard: 'Anna Kowalski',
  superuser: 'Marc Llopis',
  admin: 'Dr. Ferran Marsà',
};

interface ShellProps {
  role: Role;
  currentPage: Page;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
  children: React.ReactNode;
  breadcrumb?: { label: string; page: Page }[];
}

export default function Shell({ role, currentPage, onNavigate, onLogout, children, breadcrumb }: ShellProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const visibleNav = NAV.filter((n) => n.roles.includes(role));
  const activePage = TOP_LEVEL_PAGES.includes(currentPage) ? currentPage : TOP_LEVEL_PAGES.find((p) => currentPage.startsWith(p.split('-')[0]));
  const name = USER_NAMES[role];
  const initials = name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div className="flex min-h-screen" style={{ background: '#F4F5F7' }}>
      {/* Sidebar */}
      <aside
        className="flex flex-col shrink-0 transition-all duration-200"
        style={{
          width: collapsed ? 56 : 220,
          background: 'var(--primary)',
          minHeight: '100vh',
          position: 'sticky',
          top: 0,
          alignSelf: 'flex-start',
          height: '100vh',
        }}
      >
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-4 py-5 shrink-0">
          <div
            className="flex items-center justify-center rounded shrink-0 font-bold"
            style={{ width: 28, height: 28, background: 'var(--accent)', color: 'var(--primary)', fontFamily: 'Barlow Condensed, sans-serif', fontSize: 15 }}
          >
            M
          </div>
          {!collapsed && (
            <div>
              <div style={{ fontFamily: 'Barlow Condensed, sans-serif', fontSize: 17, fontWeight: 700, color: '#fff', letterSpacing: '0.08em', lineHeight: 1 }}>
                MOSAIC
              </div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)', letterSpacing: '0.06em', lineHeight: 1, marginTop: 2 }}>
                CORE FACILITIES
              </div>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="ml-auto p-1 rounded transition-colors"
            style={{ color: 'rgba(255,255,255,0.4)' }}
          >
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              {collapsed ? <path d="M9 18l6-6-6-6"/> : <path d="M15 18l-6-6 6-6"/>}
            </svg>
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 overflow-y-auto">
          {visibleNav.map((item) => {
            const active = activePage === item.id || currentPage === item.id;
            return (
              <div key={item.id}>
                {item.dividerBefore && (
                  <div style={{ height: 1, background: 'rgba(255,255,255,0.1)', margin: '8px 4px' }} />
                )}
                <button
                  onClick={() => onNavigate(item.id)}
                  className="w-full flex items-center gap-3 rounded-lg transition-all text-left mb-0.5"
                  style={{
                    padding: collapsed ? '8px' : '7px 10px',
                    justifyContent: collapsed ? 'center' : 'flex-start',
                    background: active ? 'rgba(255,255,255,0.14)' : 'transparent',
                    color: active ? '#fff' : 'rgba(255,255,255,0.55)',
                    borderLeft: active ? '2px solid var(--accent)' : '2px solid transparent',
                  }}
                  title={collapsed ? item.label : undefined}
                >
                  <span className="shrink-0">{item.icon}</span>
                  {!collapsed && (
                    <span style={{ fontSize: 13.5, fontWeight: active ? 600 : 400 }}>{item.label}</span>
                  )}
                </button>
              </div>
            );
          })}
        </nav>

        {/* Support link */}
        {!collapsed && (
          <div className="px-4 pb-4">
            <button
              className="w-full flex items-center gap-2 py-2 text-left rounded-lg px-2 transition-colors"
              style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10"/>
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                <line x1="12" y1="17" x2="12.01" y2="17"/>
              </svg>
              Support
            </button>
          </div>
        )}

        {/* User */}
        <div
          className="mx-2 mb-3 rounded-lg p-3"
          style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.09)' }}
        >
          <div className={`flex items-center gap-2.5 ${collapsed ? 'justify-center' : ''}`}>
            <div
              className="rounded-full flex items-center justify-center text-xs font-bold shrink-0"
              style={{ width: 32, height: 32, background: 'var(--accent)', color: 'var(--primary)', fontWeight: 800 }}
            >
              {initials}
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <div style={{ fontSize: 13, fontWeight: 600, color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {name}
                </div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)' }}>{ROLE_LABELS[role]}</div>
              </div>
            )}
          </div>
          {!collapsed && (
            <button
              onClick={onLogout}
              className="mt-2 w-full text-left text-xs transition-colors"
              style={{ color: 'rgba(255,255,255,0.35)', paddingTop: 4, borderTop: '1px solid rgba(255,255,255,0.08)' }}
            >
              Sign out →
            </button>
          )}
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header
          className="flex items-center gap-3 px-6 shrink-0"
          style={{ height: 56, background: '#fff', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 10 }}
        >
          {/* Breadcrumb */}
          <div className="flex items-center gap-1 flex-1 min-w-0">
            {breadcrumb && breadcrumb.length > 0 ? (
              <>
                {breadcrumb.map((crumb, i) => (
                  <span key={i} className="flex items-center gap-1">
                    {i > 0 && <span style={{ color: 'var(--muted-foreground)', fontSize: 13 }}>/</span>}
                    <button
                      onClick={() => onNavigate(crumb.page)}
                      style={{ fontSize: 13, color: i === breadcrumb.length - 1 ? 'var(--foreground)' : 'var(--muted-foreground)', fontWeight: i === breadcrumb.length - 1 ? 600 : 400 }}
                    >
                      {crumb.label}
                    </button>
                  </span>
                ))}
              </>
            ) : (
              <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--foreground)' }}>
                {PAGE_LABELS[currentPage] ?? currentPage}
              </span>
            )}
          </div>

          {/* Facility pill */}
          <div
            className="px-2.5 py-1 rounded text-xs font-semibold"
            style={{ background: 'var(--primary)', color: 'var(--accent)', fontFamily: 'Barlow Condensed, sans-serif', letterSpacing: '0.09em' }}
          >
            NFL
          </div>

          {/* Status */}
          <div className="hidden md:flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: 'var(--status-ok)' }} />
            <span style={{ fontSize: 12, color: 'var(--muted-foreground)' }}>Systems nominal</span>
          </div>

          {/* Lang */}
          <button
            className="p-2 rounded-lg text-xs font-semibold transition-colors hover:bg-gray-50"
            style={{ color: 'var(--muted-foreground)', border: '1px solid var(--border)' }}
          >
            EN
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setNotifOpen(!notifOpen)}
              className="p-2 rounded-lg transition-colors hover:bg-gray-50 relative"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--muted-foreground)' }}>
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
              </svg>
              <span
                className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
                style={{ background: '#EF4444' }}
              />
            </button>
            {notifOpen && (
              <div
                className="absolute right-0 top-full mt-2 rounded-xl shadow-xl w-72 overflow-hidden z-50"
                style={{ background: '#fff', border: '1px solid var(--border)' }}
              >
                <div className="px-4 py-3" style={{ borderBottom: '1px solid var(--border)' }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--foreground)' }}>Notifications</div>
                </div>
                {[
                  { text: 'EBL CRESTEC: Practical assessment approved', time: '2h ago', dot: '#10B981' },
                  { text: 'Oxford RIE: Booking reminder — today 16:00', time: '4h ago', dot: '#FFCD01' },
                  { text: 'EU-NANO-2026: Grant balance low (€3,240)', time: '1d ago', dot: '#EF4444' },
                ].map((n, i) => (
                  <div key={i} className="flex items-start gap-3 px-4 py-3" style={{ borderBottom: i < 2 ? '1px solid var(--border)' : 'none' }}>
                    <span className="w-2 h-2 rounded-full mt-1.5 shrink-0" style={{ background: n.dot }} />
                    <div>
                      <div style={{ fontSize: 12.5, color: 'var(--foreground)', lineHeight: 1.4 }}>{n.text}</div>
                      <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginTop: 2 }}>{n.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Avatar */}
          <div
            className="rounded-full flex items-center justify-center text-xs font-bold cursor-pointer"
            style={{ width: 34, height: 34, background: 'var(--primary)', color: 'var(--accent)', fontWeight: 800 }}
          >
            {initials}
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
